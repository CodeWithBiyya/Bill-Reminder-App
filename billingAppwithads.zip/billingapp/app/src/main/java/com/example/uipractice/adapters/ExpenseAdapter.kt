package com.example.uipractice.adapters

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.uipractice.databinding.ItemExpenseBinding

data class Expense(
    val name: String,
    val amount: Int,
    val colorResId: Int,
    val iconResId: Int,
    val progress: Int,
    val backgroundColor: Int
)

class ExpenseAdapter(
    private var expenses: List<Expense>,
    private val currencySymbol: String // Add currency symbol parameter
) : RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val binding = ItemExpenseBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ExpenseViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        val expense = expenses[position]
        holder.bind(expense, expenses, currencySymbol)
    }

    override fun getItemCount(): Int = expenses.size

    @SuppressLint("NotifyDataSetChanged")
    fun updateExpenses(newExpenses: List<Expense>) {
        expenses = newExpenses
        notifyDataSetChanged()
    }

    fun submitList(newList: List<Expense>) {
        expenses = newList
        notifyDataSetChanged()
    }


    class ExpenseViewHolder(private val binding: ItemExpenseBinding) : RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("SetTextI18n")
        fun bind(expense: Expense, expenses: List<Expense>, currencySymbol: String) {
            binding.expenseName.text = expense.name
            binding.expenseAmount.text = "$currencySymbol${expense.amount}" // Use the currency symbol
            binding.expenseImage.setImageResource(expense.iconResId)
            binding.expenseImageBackground.setBackgroundColor(expense.backgroundColor)

            val totalAmount = expenses.sumOf { it.amount }.toFloat()
            val percentage = if (totalAmount > 0) (expense.amount / totalAmount * 100).toInt() else 0
            binding.expenseProgressBar.progress = percentage
            binding.expensePercentage.text = "$percentage%"

            binding.expenseProgressBar.progressDrawable.setTint(
                ContextCompat.getColor(itemView.context, expense.colorResId)
            )
            binding.root.setBackgroundColor(
                ContextCompat.getColor(itemView.context, expense.backgroundColor)
            )
        }
    }
}
