package com.example.uipractice.repository

import com.example.uipractice.dataClasses.Bill
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class BillRepository {

    private val db = FirebaseFirestore.getInstance()
    private val collection = db.collection("bills")

    // Get all bills
    suspend fun getAllBills(): List<Bill> {
        return try {
            val snapshot = collection.get().await()
            snapshot.toObjects(Bill::class.java)
        } catch (e: Exception) {
            // Handle exception
            emptyList()
        }
    }

    // Get bills by category
    suspend fun getBillsByCategory(category: String): List<Bill> {
        return try {
            val snapshot = collection.whereEqualTo("category", category).get().await()
            snapshot.toObjects(Bill::class.java)
        } catch (e: Exception) {
            // Handle exception
            emptyList()
        }
    }

    // Insert a new bill
    suspend fun insertBill(bill: Bill): Boolean {
        return try {
            val documentRef = collection.add(bill).await()
            documentRef.id.isNotEmpty() // Return true if the document was added
        } catch (e: Exception) {
            // Handle exception
            false
        }
    }

    // Fetch bills by status from Firestore
    suspend fun getBillsByStatus(status: Bill.BillStatus): List<Bill> = withContext(Dispatchers.IO) {
        val snapshot = db.collection("bills")
            .whereEqualTo("status", status.name)
            .get()
            .await()  // Use 'await()' to get the result from Firestore in a coroutine
        snapshot.toObjects(Bill::class.java)
    }

    // Fetch overdue bills based on current time from Firestore
    suspend fun getOverdueBills(currentTimeMillis: Long): List<Bill> = withContext(Dispatchers.IO) {
        val snapshot = db.collection("bills")
            .whereLessThan("dueDateMillis", currentTimeMillis)
            .get()
            .await()  // Use 'await()' to get the result from Firestore in a coroutine
        snapshot.toObjects(Bill::class.java)
    }


    // Get a bill by its ID
    suspend fun getBillById(billId: String): Bill? {
        return try {
            val documentSnapshot = collection.document(billId).get().await()
            documentSnapshot.toObject(Bill::class.java)
        } catch (e: Exception) {
            // Handle exception
            null
        }
    }

    // Delete a bill
    suspend fun deleteBill(billId: String): Boolean {
        return try {
            collection.document(billId).delete().await()
            true
        } catch (e: Exception) {
            // Handle exception
            false
        }
    }

    // Update a bill
    suspend fun updateBill(billId: String, updates: Map<String, Any>): Boolean {
        return try {
            collection.document(billId).update(updates).await()
            true
        } catch (e: Exception) {
            // Handle exception
            false
        }
    }

    // Get recurring bills (assuming you have a field 'recurring' in your Firestore collection)
    suspend fun getRecurringBills(): List<Bill> {
        return try {
            val snapshot = collection.whereEqualTo("recurring", true).get().await()
            snapshot.toObjects(Bill::class.java)
        } catch (e: Exception) {
            // Handle exception
            emptyList()
        }
    }
}
