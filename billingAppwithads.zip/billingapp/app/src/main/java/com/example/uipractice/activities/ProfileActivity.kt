package com.example.uipractice.activities

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ReportFragment
import androidx.navigation.NavController
import androidx.navigation.findNavController
import com.example.uipractice.R
import com.example.uipractice.databinding.ActivityProfile2Binding
import com.example.uipractice.fragments.AllFilesFragment
import com.example.uipractice.fragments.CalenderFragment
import com.example.uipractice.fragments.CategoriesFragment
import com.example.uipractice.fragments.CurrencyFragment
import com.example.uipractice.fragments.FeedbackFragment
import com.example.uipractice.fragments.HomeFragment
import com.example.uipractice.fragments.PersonalInfoFragment
import com.example.uipractice.fragments.PrivacyPolicyFragment
import com.example.uipractice.fragments.ProfileFragment
import com.example.uipractice.fragments.RateUsFragment

class ProfileActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "ProfileActivity"
    }

    private lateinit var binding: ActivityProfile2Binding
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfile2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize NavController
        navController = findNavController(R.id.nav_host_fragment)
    }

    @SuppressLint("RestrictedApi")
    private fun navigateToFragment(fragmentId: Int) {
        val selectedFragment = when (fragmentId) {
            R.id.homeFragment -> HomeFragment()
            R.id.allFilesFragment -> AllFilesFragment()
            R.id.reportFragment -> ReportFragment()
            R.id.profileFragment -> ProfileFragment()
            R.id.personalInfoFragment -> PersonalInfoFragment()
            R.id.calenderFragment -> CalenderFragment()
            R.id.currencyFragment -> CurrencyFragment()
            R.id.categoriesFragment -> CategoriesFragment()
            R.id.privacyPolicyFragment -> PrivacyPolicyFragment()
            R.id.feedbackFragment -> FeedbackFragment()
            R.id.rateUsFragment -> RateUsFragment()
            else -> null
        }
        selectedFragment?.let {
            supportFragmentManager.beginTransaction()
                .replace(R.id.nav_host_fragment, it as Fragment) // Ensure this is the correct container ID
                .addToBackStack(null)
                .commit()
        } ?: run {
            Log.w(TAG, "navigateToFragment: Invalid fragmentId - $fragmentId")
        }
    }

    // Example calls
    private fun exampleNavigationCalls() {
        navigateToFragment(R.id.personalInfoFragment)
        navigateToFragment(R.id.calenderFragment)
        navigateToFragment(R.id.currencyFragment)
        navigateToFragment(R.id.categoriesFragment)
        navigateToFragment(R.id.privacyPolicyFragment)
        navigateToFragment(R.id.feedbackFragment)
        navigateToFragment(R.id.rateUsFragment)
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}
