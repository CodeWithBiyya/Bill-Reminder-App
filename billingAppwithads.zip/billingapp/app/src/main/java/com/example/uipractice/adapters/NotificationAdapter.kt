//package com.example.uipractice.adapters
//
//import android.content.Context
//import android.os.Handler
//import android.os.Looper
//import android.text.format.DateUtils
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.ImageView
//import android.widget.TextView
//import androidx.recyclerview.widget.RecyclerView
//import com.example.uipractice.R
//import com.example.uipractice.database.Notification
//import java.util.concurrent.TimeUnit
//
//class NotificationAdapter(
//    private val context: Context,
//    private val onDeleteClick: (Notification) -> Unit
//) : RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder>() {
//
//    private var notifications: List<Notification> = emptyList()
//    private val handler = Handler(Looper.getMainLooper())
//    private val updateInterval = TimeUnit.SECONDS.toMillis(60) // Update every 60 seconds
//
//    inner class NotificationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        val title: TextView = itemView.findViewById(R.id.notificationTitle)
//        val message: TextView = itemView.findViewById(R.id.notificationMessage)
//        val timestamp: TextView = itemView.findViewById(R.id.notificationTime)
//        val deleteButton: ImageView = itemView.findViewById(R.id.btn_delete)
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotificationViewHolder {
//        val itemView = LayoutInflater.from(context).inflate(R.layout.item_notification, parent, false)
//        return NotificationViewHolder(itemView)
//    }
//
//    override fun onBindViewHolder(holder: NotificationViewHolder, position: Int) {
//        val current = notifications[position]
//        holder.title.text = current.title
//        holder.message.text = current.message
//
//        // Initial timestamp setting
//        updateTimestamp(holder.timestamp, current.timestamp)
//
//        // Update the timestamp periodically
//        handler.post(object : Runnable {
//            override fun run() {
//                updateTimestamp(holder.timestamp, current.timestamp)
//                handler.postDelayed(this, updateInterval)
//            }
//        })
//
//        // Set up the delete button click listener
//        holder.deleteButton.setOnClickListener {
//            onDeleteClick(current)
//        }
//    }
//
//    override fun getItemCount() = notifications.size
//
//    // Method to update the adapter's data
//    fun submitList(newNotifications: List<Notification>) {
//        notifications = newNotifications
//        notifyDataSetChanged() // Update the RecyclerView with new data
//    }
//
//    // Method to calculate the time difference and return a custom message for each notification
//    private fun updateTimestamp(timestampView: TextView, notificationTimestamp: Long) {
//        val currentTime = System.currentTimeMillis()
//        val timeDifference = currentTime - notificationTimestamp
//
//        val timeMessage = when {
//            timeDifference < DateUtils.MINUTE_IN_MILLIS -> "Just now"
//            timeDifference < DateUtils.HOUR_IN_MILLIS -> {
//                val minutes = (timeDifference / DateUtils.MINUTE_IN_MILLIS).toInt()
//                "$minutes Minute${if (minutes > 1) "s" else ""} ago"
//            }
//            timeDifference < DateUtils.DAY_IN_MILLIS -> {
//                val hours = (timeDifference / DateUtils.HOUR_IN_MILLIS).toInt()
//                "$hours Hour${if (hours > 1) "s" else ""} ago"
//            }
//            else -> {
//                val days = (timeDifference / DateUtils.DAY_IN_MILLIS).toInt()
//                "$days Day${if (days > 1) "s" else ""} ago"
//            }
//        }
//
//        timestampView.text = timeMessage
//    }
//}

package com.example.uipractice.adapters

import android.content.Context
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.uipractice.R
import com.example.uipractice.dataClasses.Notification

class NotificationAdapter(
    private val context: Context,
    private val onDeleteClick: (Notification) -> Unit
) : RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder>() {

    private var notifications: List<Notification> = emptyList()

    inner class NotificationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.notificationTitle)
        val message: TextView = itemView.findViewById(R.id.notificationMessage)
        val timestamp: TextView = itemView.findViewById(R.id.notificationTime)
        val deleteButton: ImageView = itemView.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotificationViewHolder {
        val itemView = LayoutInflater.from(context).inflate(R.layout.item_notification, parent, false)
        return NotificationViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: NotificationViewHolder, position: Int) {
        val current = notifications[position]
        holder.title.text = current.title
        holder.message.text = current.message
        updateTimestamp(holder.timestamp, current.timestamp)

        holder.deleteButton.setOnClickListener {
            onDeleteClick(current)
        }
    }

    override fun getItemCount() = notifications.size

    fun submitList(newNotifications: List<Notification>) {
        notifications = newNotifications
        notifyDataSetChanged()
    }

    private fun updateTimestamp(timestampView: TextView, notificationTimestamp: Long) {
        val currentTime = System.currentTimeMillis()
        val timeDifference = currentTime - notificationTimestamp

        val timeMessage = when {
            timeDifference < DateUtils.MINUTE_IN_MILLIS -> "Just now"
            timeDifference < DateUtils.HOUR_IN_MILLIS -> {
                val minutes = (timeDifference / DateUtils.MINUTE_IN_MILLIS).toInt()
                "$minutes Minute${if (minutes > 1) "s" else ""} ago"
            }
            timeDifference < DateUtils.DAY_IN_MILLIS -> {
                val hours = (timeDifference / DateUtils.HOUR_IN_MILLIS).toInt()
                "$hours Hour${if (hours > 1) "s" else ""} ago"
            }
            else -> {
                val days = (timeDifference / DateUtils.DAY_IN_MILLIS).toInt()
                "$days Day${if (days > 1) "s" else ""} ago"
            }
        }

        timestampView.text = timeMessage
    }
}
