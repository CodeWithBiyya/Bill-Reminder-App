// CurrencyFragment.kt
package com.example.uipractice.fragments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import com.example.uipractice.dataClasses.Currency
import com.example.uipractice.database.CurrencyDatabaseHelper
import com.example.uipractice.databinding.FragmentCurrenciesBinding

class CurrencyFragment : Fragment() {

    private var _binding: FragmentCurrenciesBinding? = null
    private val binding get() = _binding!!
    private lateinit var dbHelper: CurrencyDatabaseHelper

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCurrenciesBinding.inflate(inflater, container, false)
        dbHelper = CurrencyDatabaseHelper(requireContext()) // Initialize the database helper
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Handle update button click
        binding.updateButton.setOnClickListener {
            val selectedCurrencyId = binding.rgCurrency.checkedRadioButtonId
            if (selectedCurrencyId != -1) {
                val selectedRadioButton = binding.root.findViewById<RadioButton>(selectedCurrencyId)
                val selectedCurrency = selectedRadioButton.text.toString()

                // Extract the symbol from the selected currency
                val currencySymbol = when (selectedCurrency) {
                    "Dollar ($)" -> "$"
                    "Euro (€)" -> "€"
                    "Indian Rupees (INR)" -> "₹"
                    "Pakistani Rupees (PKR)" -> "PKR"
                    "GPB (£)" -> "£"
                    else -> "$"
                }

                // Update the currency in the app and save to the database
                updateAppCurrency(selectedCurrency, currencySymbol)
                saveCurrencyToDatabase(selectedCurrency, currencySymbol)

                println("Selected currency: $selectedCurrency")
                Toast.makeText(requireContext(), "Selected Currency: $selectedCurrency", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Please select a currency", Toast.LENGTH_SHORT).show()
            }
        }

        // Handle back button click
        binding.imageView.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                requireActivity().supportFragmentManager.popBackStack()
            }
        })
    }

    private fun updateAppCurrency(currency: String, currencySymbol: String) {
        val sharedPreferences = requireContext().getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("selected_currency", currency)
        editor.putString("selected_currency_symbol", currencySymbol) // Save the symbol as well
        editor.apply()

        // Notify other parts of the app if needed
        notifyCurrencyChange(currency)
    }

    private fun saveCurrencyToDatabase(currencyName: String, currencySymbol: String) {
        val currency = Currency(name = currencyName, symbol = currencySymbol)
        val rowId = dbHelper.insertCurrency(currency)
        if (rowId != -1L) {
            Toast.makeText(requireContext(), "Currency saved to database", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(requireContext(), "Failed to save currency", Toast.LENGTH_SHORT).show()
        }
    }

    private fun notifyCurrencyChange(currency: String) {
        val intent = Intent("com.example.uipractice.CURRENCY_CHANGE")
        intent.putExtra("selected_currency", currency)
        requireContext().sendBroadcast(intent)
        Toast.makeText(requireContext(), "Currency updated to: $currency", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
