package com.example.uipractice.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.uipractice.R
import com.example.uipractice.adapters.CategoryAdapter
import com.example.uipractice.dataClasses.Category
import com.example.uipractice.database.FirestoreDatabase
import com.example.uipractice.databinding.FragmentCategoriesBinding
import com.google.firebase.firestore.ktx.toObject

class CategoriesFragment : Fragment() {

    private var _binding: FragmentCategoriesBinding? = null
    private val binding get() = _binding!!
    private lateinit var categoryAdapter: CategoryAdapter
    private val firestoreDatabase = FirestoreDatabase.getDatabase() // Get FirestoreDatabase instance

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCategoriesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.imageView.setOnClickListener {
            findNavController().navigate(R.id.action_categoriesFragment_to_profileFragment)
        }

        // Set up category adapter and RecyclerView
        categoryAdapter = CategoryAdapter { category ->
            val bundle = Bundle().apply {
                putString("categoryName", category.name)
            }
            if (category.name == "Create") {
                findNavController().navigate(R.id.action_categoriesFragment_to_createCategoryFragment)
            } else {
                findNavController().navigate(R.id.action_categoriesFragment_to_categoryDetailsFragment, bundle)
            }
        }

        binding.recyclerViewCategories.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewCategories.adapter = categoryAdapter

        // Fetch categories from Firestore
        fetchCategoriesFromFirestore()

        binding.imageView14.setOnClickListener {
            findNavController().navigate(R.id.action_categoriesFragment_to_createCategoryFragment)
        }
    }

    private fun fetchCategoriesFromFirestore() {
        firestoreDatabase.categoryCollection
            .get()
            .addOnSuccessListener { result ->
                val categoriesList = mutableListOf<Category>()
                for (document in result) {
                    val category = document.toObject<Category>()
                    categoriesList.add(category)
                }
                categoryAdapter.submitList(categoriesList)
            }
            .addOnFailureListener { exception ->
                Toast.makeText(requireContext(), "Error getting categories: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
