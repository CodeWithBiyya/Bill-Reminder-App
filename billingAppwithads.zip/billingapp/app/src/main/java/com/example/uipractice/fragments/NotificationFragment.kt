package com.example.uipractice.fragments

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.uipractice.R
import com.example.uipractice.adapters.NotificationAdapter
import com.example.uipractice.dataClasses.Notification
import com.example.uipractice.database.FirestoreDatabase
import com.example.uipractice.databinding.FragmentNotificationBinding
import com.example.uipractice.viewmodel.BillViewModel
import com.example.uipractice.viewmodal.NotificationViewModel
import com.google.firebase.firestore.ktx.toObject
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class NotificationFragment : Fragment() {

    private lateinit var notificationViewModel: NotificationViewModel
    private lateinit var billViewModel: BillViewModel
    private lateinit var adapter: NotificationAdapter
    private lateinit var binding: FragmentNotificationBinding

    // Firestore instance
    private val firestoreDatabase = FirestoreDatabase.getDatabase()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentNotificationBinding.inflate(inflater, container, false)

        createNotificationChannel()

        // Initialize RecyclerView
        val recyclerView = binding.recyclerViewNotifications
        adapter = NotificationAdapter(requireContext()) { notification ->
            // Handle notification click
        }
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(context)

        // Initialize ViewModels
        notificationViewModel = ViewModelProvider(this).get(NotificationViewModel::class.java)
        billViewModel = ViewModelProvider(this).get(BillViewModel::class.java)

        // Fetch and observe notifications from Firestore
        fetchNotificationsFromFirestore()

        binding.backArrow.setOnClickListener {
            requireActivity().onBackPressed()
        }

        // Schedule notifications based on bills
        scheduleNotificationsForAllBills()
        loadUserProfile()

        return binding.root
    }

    private fun fetchNotificationsFromFirestore() {
        firestoreDatabase.notificationCollection
            .get()
            .addOnSuccessListener { result ->
                val notificationsList = mutableListOf<Notification>()
                for (document in result) {
                    val notification = document.toObject<Notification>()
                    notificationsList.add(notification)
                }
                adapter.submitList(notificationsList)
            }
            .addOnFailureListener { exception ->
                Log.e("NotificationFragment", "Error fetching notifications: ${exception.message}")
            }
    }

    private fun loadUserProfile() {
        val sharedPref = activity?.getSharedPreferences("UserInfo", Context.MODE_PRIVATE)
        val userName = sharedPref?.getString("name", "Default Name")
        binding.profileName.text = userName

        val imageView: ImageView = binding.profileImage
        val userProfileImageUri = sharedPref?.getString("imageUri", null)
        if (userProfileImageUri != null) {
            val imageUri = Uri.parse(userProfileImageUri)
            Glide.with(this)
                .load(imageUri)
                .apply(RequestOptions.circleCropTransform())
                .placeholder(R.drawable.ic_person)
                .error(R.drawable.ic_person)
                .into(imageView)
        } else {
            Glide.with(this)
                .load(R.drawable.ic_person)
                .apply(RequestOptions.circleCropTransform())
                .into(imageView)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "bill_reminder_channel",
                "Bill Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Channel for bill reminders"
            }
            val manager = requireActivity().getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun scheduleNotificationsForAllBills() {
        billViewModel.allBills.observe(viewLifecycleOwner) { bills ->
            bills?.forEach { bill ->
                val reminderTimeMillis = bill.reminderTime

                val notification = Notification(
                    id = bill.id,
                    title = "Bill Reminder",
                    message = "Your ${bill.category} bill is due soon.",
                    timestamp = reminderTimeMillis
                )

                val currentTime = System.currentTimeMillis()

                if (currentTime >= reminderTimeMillis && currentTime < (reminderTimeMillis + 60000)) {
                    lifecycleScope.launch {
                        // Check Firestore if notification already exists
                        val existingNotification = firestoreDatabase.notificationCollection
                            .whereEqualTo("id", bill.id)
                            .get()
                            .await()

                        if (existingNotification.isEmpty) {
                            // Insert notification into Firestore and schedule it
                            firestoreDatabase.notificationCollection
                                .document(bill.id.toString())
                                .set(notification)
                                .addOnSuccessListener {
                                    scheduleNotification(requireContext(), notification)
                                }
                                .addOnFailureListener {
                                    Log.e("NotificationFragment", "Failed to insert notification")
                                }
                        }
                    }
                }
            }
        }
    }

    @SuppressLint("ScheduleExactAlarm")
    private fun scheduleNotification(context: Context, notification: Notification) {
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra("title", notification.title)
            putExtra("message", notification.message)
            putExtra("id", notification.id)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            notification.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, notification.timestamp, pendingIntent)
    }

    private fun parseDate(dateString: String): Date? {
        val formats = arrayOf("yyyy-MM-dd", "dd/MM/yyyy", "MM/dd/yyyy")
        for (format in formats) {
            try {
                return SimpleDateFormat(format, Locale.getDefault()).parse(dateString)
            } catch (e: ParseException) {
                // Ignore and try the next format
            }
        }
        return null
    }
}
