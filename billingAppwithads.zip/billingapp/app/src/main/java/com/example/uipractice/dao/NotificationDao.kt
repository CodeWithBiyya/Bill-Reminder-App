package com.example.uipractice.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.uipractice.dataClasses.Notification

@Dao
interface NotificationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: Notification)

    @Query("SELECT * FROM notifications WHERE  timestamp = :currentTime ORDER BY timestamp DESC")
    fun getNotificationsMatchingCurrentTime(currentTime: Long): LiveData<List<Notification>>

    @Query("SELECT * FROM notifications  ORDER BY timestamp DESC")
    fun getAllNotifications(): LiveData<List<Notification>>

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteNotification(id: Int)

    @Query("SELECT * FROM notifications WHERE id = :id")
    fun getNotificationById(id: Int): LiveData<Notification?>


    @Query("SELECT * FROM notifications WHERE timestamp = :timestamp")
    fun getNotificationByTimestamp(timestamp: Long): LiveData<Notification?>
}


