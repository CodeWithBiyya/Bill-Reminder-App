package com.example.uipractice.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.uipractice.R

class RateUsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_rate_us, container, false)

        // Find views
        val imageView = view.findViewById<ImageView>(R.id.imageView)
        val yesButton = view.findViewById<ImageButton>(R.id.yesButton)
        val noButton = view.findViewById<ImageButton>(R.id.noButton)

        // Back arrow click listener
        imageView.setOnClickListener {
            // Navigate back to ProfileFragment when the back arrow is clicked
            findNavController().navigate(R.id.action_rateUsFragment_to_profileFragment)
        }

        // Yes button click listener
        yesButton.setOnClickListener {
            // Show a Toast message when the "Yes" button is clicked
            Toast.makeText(requireContext(), "Thank you for liking our app!", Toast.LENGTH_SHORT).show()
            // You can add more logic here, such as saving the feedback or updating the UI
        }

        // No button click listener
        noButton.setOnClickListener {
            // Show a Toast message when the "No" button is clicked
            Toast.makeText(requireContext(), "We appreciate your feedback!", Toast.LENGTH_SHORT).show()
            // You can add more logic here, such as saving the feedback or updating the UI
        }

        return view
    }
}
