package com.example.uipractice.fragments

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.uipractice.R
import com.example.uipractice.adapters.ImageGalleryAdapter
import com.example.uipractice.databinding.FragmentGalleryBinding
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GalleryFragment : Fragment() {

    private lateinit var binding: FragmentGalleryBinding
    private val REQUEST_STORAGE_PERMISSION = 1002
    private val REQUEST_IMAGE_CAPTURE = 1003
    private val imageList = mutableListOf<String>()
    private lateinit var imageAdapter: ImageGalleryAdapter
    private var currentPhotoUri: Uri? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentGalleryBinding.inflate(inflater, container, false)

        // Set the current date
        val currentDate = SimpleDateFormat("d MMM yyyy, EEEE", Locale.getDefault()).format(Date())
        binding.tvGalleryDate.text = currentDate

        binding.toolbar.setNavigationOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        binding.btnShare.setOnClickListener {
            shareSelectedImages()
        }

        binding.btnDelete.setOnClickListener {
            deleteSelectedImages()
        }

        setupRecyclerView()

        if (hasStoragePermission()) {
            loadCapturedImagesFromGallery()
        } else {
            requestStoragePermission()
        }

        // Register broadcast receiver for new image notifications
        requireContext().registerReceiver(imageAddedReceiver, IntentFilter("com.example.uipractice.NEW_IMAGE_ADDED"))

        return binding.root
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            currentPhotoUri?.let { uri ->
                MediaScannerConnection.scanFile(requireContext(), arrayOf(uri.path), arrayOf("image/jpeg"), null)
                loadCapturedImagesFromGallery()
            }
        }
    }

    private fun createImageFile(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoUri = Uri.fromFile(this)
        }
    }

    private fun setupRecyclerView() {
        imageAdapter = ImageGalleryAdapter(imageList) { position, isSelected ->
            // Handle image selection callback if needed
        }
        binding.rvImages.layoutManager = GridLayoutManager(requireContext(), 3)
        binding.rvImages.adapter = imageAdapter
    }

    private fun hasStoragePermission(): Boolean {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestStoragePermission() {
        ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_STORAGE_PERMISSION)
    }

    private fun loadCapturedImagesFromGallery() {
        imageList.clear()
        val projection = arrayOf(MediaStore.Images.Media._ID)
        val cursor = requireContext().contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )

        cursor?.use {
            val idColumn = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            while (it.moveToNext()) {
                val id = it.getLong(idColumn)
                val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                imageList.add(uri.toString())
            }
        }

        imageAdapter.notifyDataSetChanged() // Notify adapter that data has changed
    }

    private fun deleteSelectedImages() {
        val selectedImages = imageAdapter.getSelectedImages()
        if (selectedImages.isNotEmpty()) {
            selectedImages.forEach { uriString ->
                val uri = Uri.parse(uriString)
                try {
                    val rowsDeleted = requireContext().contentResolver.delete(uri, null, null)
                    if (rowsDeleted > 0) {
                        imageList.remove(uriString)
                    }
                } catch (e: SecurityException) {
                    // Handle or log security exception
                    Toast.makeText(requireContext(), "Permission issue with deleting image.", Toast.LENGTH_SHORT).show()
                }
            }
            imageAdapter.clearSelections()
            imageAdapter.notifyDataSetChanged()
            Toast.makeText(requireContext(), "Selected images deleted.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(requireContext(), "No images selected to delete.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareSelectedImages() {
        val selectedImages = imageAdapter.getSelectedImages()
        if (selectedImages.isNotEmpty()) {
            val uris = selectedImages.map { Uri.parse(it) }
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND_MULTIPLE
                type = "image/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            }
            startActivity(Intent.createChooser(shareIntent, "Share images via"))
        } else {
            Toast.makeText(requireContext(), "No images selected to share.", Toast.LENGTH_SHORT).show()
        }
    }

    private val imageAddedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.example.uipractice.NEW_IMAGE_ADDED") {
                loadCapturedImagesFromGallery()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_STORAGE_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted, proceed with accessing the images
                    loadCapturedImagesFromGallery()
                } else {
                    Toast.makeText(context, "Read Storage Permission Denied", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        requireContext().unregisterReceiver(imageAddedReceiver)
    }
}
