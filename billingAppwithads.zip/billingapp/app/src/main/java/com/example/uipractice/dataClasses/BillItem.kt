package com.example.uipractice.dataClasses

//data class BillItem(
//    val categoryName: String,
//    val amount: Double,
//    val dueDate: String,
//    val progress: Int // Progress percentage
//)

data class BillItem(
    val categoryName: String = "",
    val amount: Double = 0.0,
    val dueDate: String = "",
    val progress: Int = 0
)


