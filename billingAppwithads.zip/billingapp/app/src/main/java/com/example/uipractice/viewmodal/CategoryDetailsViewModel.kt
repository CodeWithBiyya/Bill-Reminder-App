package com.example.uipractice.viewmodal

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.repository.BillRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CategoryDetailsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BillRepository() // Initialize Firebase BillRepository

    // MutableLiveData to hold the category name
    private val _categoryName = MutableLiveData<String>()

    // MutableLiveData to hold the list of bills by category
    private val _billsByCategory = MutableLiveData<List<Bill>>()
    val bills: LiveData<List<Bill>> get() = _billsByCategory

    // Function to set category name and trigger data fetch
    fun setCategoryName(categoryName: String) {
        _categoryName.value = categoryName
        fetchBillsByCategory(categoryName)
    }

    // Function to fetch bills by category from Firebase
    private fun fetchBillsByCategory(categoryName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Fetch bills from the repository
                val billsList = repository.getBillsByCategory(categoryName)
                withContext(Dispatchers.Main) {
                    _billsByCategory.value = billsList // Update LiveData on the main thread
                }
            } catch (e: Exception) {
                // Handle any errors here
                withContext(Dispatchers.Main) {
                    _billsByCategory.value = emptyList() // Return an empty list in case of error
                }
            }
        }
    }

    // Function to retrieve bills by category from LiveData
    fun getBillsByCategory(categoryName: String): LiveData<List<Bill>> {
        setCategoryName(categoryName)
        return bills
    }
}
