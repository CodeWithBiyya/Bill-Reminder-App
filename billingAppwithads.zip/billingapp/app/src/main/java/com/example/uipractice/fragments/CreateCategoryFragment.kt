package com.example.uipractice.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.uipractice.R
import com.example.uipractice.dataClasses.Category
import com.example.uipractice.viewmodal.HomeViewModel
import com.google.firebase.firestore.FirebaseFirestore

class CreateCategoryFragment : Fragment() {

    private lateinit var categoryNameEditText: EditText
    private lateinit var categoryDescriptionEditText: EditText
    private lateinit var categoryLogoSpinner: Spinner
    private lateinit var createButton: Button
    private lateinit var viewModel: HomeViewModel
    private lateinit var db: FirebaseFirestore
    private lateinit var categoryList: MutableList<Category>

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_create_category, container, false)

        val imageView: ImageView = view.findViewById(R.id.imageView)
        imageView.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        categoryNameEditText = view.findViewById(R.id.category_name)
        categoryDescriptionEditText = view.findViewById(R.id.category_description)
        categoryLogoSpinner = view.findViewById(R.id.category_logo)
        createButton = view.findViewById(R.id.create_button)

        viewModel = ViewModelProvider(requireActivity()).get(HomeViewModel::class.java)
        db = FirebaseFirestore.getInstance()

        loadCategoriesFromFirestore()

        createButton.setOnClickListener {
            createCategory()
        }

        return view
    }

    private fun loadCategoriesFromFirestore() {
        db.collection("categories")
            .get()
            .addOnSuccessListener { documents ->
                categoryList = documents.toObjects(Category::class.java)
                populateCategorySpinner(categoryList)
            }
            .addOnFailureListener { exception ->
                Toast.makeText(requireContext(), "Failed to load categories", Toast.LENGTH_SHORT).show()
            }
    }

    private fun populateCategorySpinner(categories: List<Category>) {
        val categoryNames = categories.map { it.name }
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categoryNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categoryLogoSpinner.adapter = adapter
    }

    private fun createCategory() {
        val categoryName = categoryNameEditText.text.toString().trim()
        val categoryDescription = categoryDescriptionEditText.text.toString().trim()
        val selectedCategoryName = categoryLogoSpinner.selectedItem.toString()

        val selectedCategory = categoryList.find { it.name == selectedCategoryName }
        val categoryLogoResourceId = selectedCategory?.logoResourceId ?: R.drawable.default_icon

        if (categoryName.isEmpty() || categoryDescription.isEmpty()) {
            Toast.makeText(requireContext(), "Please fill out all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val category = Category(name = categoryName, logoResourceId = categoryLogoResourceId)

        viewModel.addCategory(category)

        Toast.makeText(requireContext(), "Category created successfully", Toast.LENGTH_SHORT).show()
        requireActivity().supportFragmentManager.popBackStack()
    }
}
