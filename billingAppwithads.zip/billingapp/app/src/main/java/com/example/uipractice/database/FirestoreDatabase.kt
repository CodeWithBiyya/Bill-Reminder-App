package com.example.uipractice.database

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class FirestoreDatabase private constructor() {

    val db: FirebaseFirestore = Firebase.firestore

    // Collections for different entities
    val billCollection = db.collection("bills")
    val notificationCollection = db.collection("notifications")
    val categoryCollection = db.collection("categories")

    companion object {
        @Volatile
        private var INSTANCE: FirestoreDatabase? = null

        fun getDatabase(): FirestoreDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = FirestoreDatabase()
                INSTANCE = instance
                instance
            }
        }
    }
}
