package com.example.uipractice.dataClasses

data class Currency(
    val id: Long = 0,
    val name: String = "",
    val symbol: String = ""
)
