package com.example.uipractice.fragments

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.uipractice.R
import com.example.uipractice.adapters.BillAdapter
import com.example.uipractice.adapters.BillCategoryAdapter
import com.example.uipractice.adapters.CategoryAdapter
import com.example.uipractice.adapters.OnBillClickListener
import com.example.uipractice.adapters.ViewPagerAdapter
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.dataClasses.Category
import com.example.uipractice.databinding.FragmentHomeBinding
import com.example.uipractice.viewmodal.HomeViewModel
import com.example.uipractice.viewmodel.BillViewModel
import com.google.android.material.tabs.TabLayoutMediator
import com.google.firebase.firestore.FirebaseFirestore

class HomeFragment : Fragment(), OnBillClickListener {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var billCategoryAdapter: BillCategoryAdapter
    private lateinit var billViewModel: BillViewModel
    private lateinit var billAdapter: BillAdapter
    private val db = FirebaseFirestore.getInstance()  // Firestore instance

    private lateinit var viewModel: HomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Load user info and profile picture
        val sharedPref = activity?.getSharedPreferences("UserInfo", Context.MODE_PRIVATE)
        val imageUriString = sharedPref?.getString("imageUri", null)
        val imageView: ImageView = binding.profilePicture

        if (imageUriString != null) {
            val imageUri = Uri.parse(imageUriString)
            Glide.with(this)
                .load(imageUri)
                .apply(RequestOptions.circleCropTransform())
                .placeholder(R.drawable.ic_person)
                .error(R.drawable.ic_person)
                .into(imageView)
        } else {
            Glide.with(this)
                .load(R.drawable.ic_person)
                .apply(RequestOptions.circleCropTransform())
                .into(imageView)
        }

        // Initialize ViewModels
        billViewModel = ViewModelProvider(this)[BillViewModel::class.java]
        viewModel = ViewModelProvider(this)[HomeViewModel::class.java]

        // Initialize adapters
        val currencySymbol = getSelectedCurrencySymbol(requireContext())
        billCategoryAdapter = BillCategoryAdapter(emptyList(), currencySymbol)
        billAdapter = BillAdapter(this, currencySymbol)

        categoryAdapter = CategoryAdapter { category ->
            // Handle category click
            Toast.makeText(requireContext(), "Clicked on: ${category.name}", Toast.LENGTH_SHORT).show()
        }
        binding.recyclerViewBillCategories.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerViewBillCategories.adapter = billCategoryAdapter

        binding.recyclerViewBills.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerViewBills.adapter = billAdapter

        // Set the adapter for category RecyclerView
        binding.recyclerViewCategories.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerViewCategories.adapter = categoryAdapter

        // Fetch data from Firestore
        fetchCategoriesFromFirestore()
        fetchBillsFromFirestore()

        // TabLayout and ViewPager
        val viewPagerAdapter = ViewPagerAdapter(this)
        binding.viewPager.adapter = viewPagerAdapter
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "Upcoming"
                1 -> "Paid"
                2 -> "Overdue"
                3 -> "Recurring"
                else -> "Unknown"
            }
        }.attach()

        // Observe bill ViewModel for updates
        billViewModel.upcomingBills.observe(viewLifecycleOwner) { bills ->
            if (binding.viewPager.currentItem == 0) {
                billAdapter.submitList(bills)
            }
        }

        billViewModel.paidBills.observe(viewLifecycleOwner) { bills ->
            if (binding.viewPager.currentItem == 1) {
                billAdapter.submitList(bills)
            }
        }

        billViewModel.overdueBills.observe(viewLifecycleOwner) { bills ->
            if (binding.viewPager.currentItem == 2) {
                billAdapter.submitList(bills)
            }
        }

        billViewModel.recurringBills.observe(viewLifecycleOwner) { bills ->
            if (binding.viewPager.currentItem == 3) {
                billAdapter.submitList(bills)
            }
        }

        binding.imageView15.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_reportFragment)
        }

        binding.imageView16.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_allFilesFragment)
        }
    }

    // Fetch categories from Firestore
    private fun fetchCategoriesFromFirestore() {
        db.collection("categories")
            .get()
            .addOnSuccessListener { result ->
                val categories = result.map { document ->
                    document.toObject(Category::class.java)
                }
                categoryAdapter.submitList(categories)
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Error fetching categories: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    // Fetch bills from Firestore
    private fun fetchBillsFromFirestore() {
        db.collection("bills")
            .get()
            .addOnSuccessListener { result ->
                val bills = result.map { document ->
                    document.toObject(Bill::class.java)
                }
                billAdapter.submitList(bills)
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Error fetching bills: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    // Helper function to get the selected currency symbol
    private fun getSelectedCurrencySymbol(context: Context): String {
        val sharedPreferences = context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("selected_currency_symbol", "$") ?: "$"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Method to retrieve currency by name from the database
    override fun onBillClicked(bill: Bill) {
        Toast.makeText(requireContext(), "Clicked on: ${bill.description}", Toast.LENGTH_SHORT)
            .show()
        val dialog = BillDetailsDialog.newInstance(bill)
        val bundle = Bundle()
        bundle.putParcelable("bill", bill) // Ensure Bill is Parcelable
        dialog.arguments = bundle
        dialog.show(parentFragmentManager, "BillDetailsDialog")
    }


}
