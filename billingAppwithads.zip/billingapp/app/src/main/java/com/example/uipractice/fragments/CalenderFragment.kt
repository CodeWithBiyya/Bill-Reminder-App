package com.example.uipractice.fragments

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.databinding.FragmentCalenderBinding
import com.example.uipractice.viewmodel.BillViewModel
import com.prolificinteractive.materialcalendarview.CalendarDay
import com.prolificinteractive.materialcalendarview.DayViewDecorator
import com.prolificinteractive.materialcalendarview.DayViewFacade
import com.prolificinteractive.materialcalendarview.MaterialCalendarView
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CalenderFragment : Fragment() {

        private lateinit var billViewModel: BillViewModel
        private lateinit var calendarView: MaterialCalendarView

        override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {
            val binding = FragmentCalenderBinding.inflate(inflater, container, false)
            calendarView = binding.calendarView

            // Initialize the ViewModel
            billViewModel = ViewModelProvider(this).get(BillViewModel::class.java)

            // Observe the bill data and update the calendar
            billViewModel.allBills.observe(viewLifecycleOwner, Observer { bills ->
                val dueDates = mutableListOf<CalendarDay>()
                val overdueDates = mutableListOf<CalendarDay>()
                val paidDates = mutableListOf<CalendarDay>()

                for (bill in bills) {
                    val calendarDay = convertDateToCalendarDay(bill.dueDate)

                    when {
                        isOverdue(bill) -> overdueDates.add(calendarDay)
                        isPaid(bill) -> paidDates.add(calendarDay)
                        else -> dueDates.add(calendarDay)
                    }
                }

                calendarView.removeDecorators()
                calendarView.addDecorator(BillStatusDecorator(dueDates, Color.parseColor("#FFA500")))
                calendarView.addDecorator(BillStatusDecorator(overdueDates, Color.parseColor("#FF0000")))
                calendarView.addDecorator(BillStatusDecorator(paidDates, Color.parseColor("#29B6F6")))
            })

            return binding.root
        }

    // Convert the string date (e.g., "22:53 23/09/2024") to CalendarDay
    private fun convertDateToCalendarDay(dateStr: String): CalendarDay {
        val sdf = SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault())  // Ensure correct locale is used
        try {
            Log.d("CalendarFragment", "Parsing date: $dateStr")  // Log the date being parsed
            val date = sdf.parse(dateStr) ?: throw IllegalArgumentException("Invalid date")
            val calendar = Calendar.getInstance()
            calendar.time = date

            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH) + 1  // Adjust for zero-based months
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            return CalendarDay.from(year, month, day)
        } catch (e: ParseException) {
            Log.e("CalendarFragment", "Failed to parse date: $dateStr", e)  // Log the error
            throw IllegalArgumentException("Failed to parse date: $dateStr")
        }
    }


    // Logic to check if the bill is overdue
    private fun isOverdue(bill: Bill): Boolean {
        val currentDate = Calendar.getInstance().time
        val sdf = SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault())  // Ensure correct format is used
        return try {
            val dueDate = sdf.parse(bill.dueDate) ?: throw IllegalArgumentException("Invalid date")
            dueDate.before(currentDate)
        } catch (e: ParseException) {
            Log.e("CalendarFragment", "Failed to parse due date: ${bill.dueDate}", e)
            false  // Return false in case of a parsing error
        }
    }

        // Logic to check if the bill is paid
        private fun isPaid(bill: Bill): Boolean {
            // Assume there is a field in Bill that tracks payment status
            return bill.isPaid
        }
    }

class BillStatusDecorator(
    private val dates: Collection<CalendarDay>,
    private val color: Int
) : DayViewDecorator {

    override fun shouldDecorate(day: CalendarDay): Boolean {
        return dates.contains(day)
    }

    override fun decorate(view: DayViewFacade) {
        view.addSpan(object : DotSpan(10f, color) {})  // Add a colored dot under the day
    }
}


open class DotSpan(private val radius: Float, private val color: Int) : android.text.style.LineBackgroundSpan {
    override fun drawBackground(
        canvas: Canvas,
        paint: Paint,
        left: Int,
        right: Int,
        top: Int,
        lineHeight: Int,
        bottom: Int,
        text: CharSequence,
        start: Int,
        end: Int,
        lineNumber: Int
    ) {
        paint.color = color
        canvas.drawCircle((left + right) / 2f, (top + bottom) / 2f, radius, paint)
    }
}
