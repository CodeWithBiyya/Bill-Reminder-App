package com.example.uipractice.dao

import androidx.room.Dao
import com.example.uipractice.dataClasses.Bill
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

@Dao
interface BillDao {

//    @Query("SELECT * FROM bill_table")
//    fun getAllBills(): LiveData<List<Bill>>

    fun getAllBills(callback: (List<Bill>) -> Unit) {
        FirebaseFirestore.getInstance().collection("bills")
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    // Handle the error
                    return@addSnapshotListener
                }
                val bills = snapshot?.toObjects(Bill::class.java) ?: emptyList()
                callback(bills)
            }
    }


//    @Query("SELECT * FROM bill_table WHERE id = :billId LIMIT 1")
//    fun getBillById(billId: Int): LiveData<Bill>

    fun getBillById(billId: String, callback: (Bill?) -> Unit) {
        FirebaseFirestore.getInstance().collection("bills").document(billId)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    // Handle the error
                    return@addSnapshotListener
                }
                val bill = snapshot?.toObject(Bill::class.java)
                callback(bill)
            }
    }

//
//    @Insert(onConflict = OnConflictStrategy.IGNORE)
//    suspend fun insertBill(bill: Bill)
fun insertBill(bill: Bill, callback: (Boolean) -> Unit) {
    FirebaseFirestore.getInstance().collection("bills").document(bill.id)
        .set(bill)
        .addOnSuccessListener {
            callback(true)
        }
        .addOnFailureListener {
            callback(false)
        }
}

//
//    @Query("SELECT * FROM bill_table WHERE category = :category")
//    fun getBillsByCategory(category: String): LiveData<List<Bill>>

    fun getBillsByCategory(category: String, callback: (List<Bill>) -> Unit) {
        FirebaseFirestore.getInstance().collection("bills")
            .whereEqualTo("category", category)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    // Handle the error
                    return@addSnapshotListener
                }
                val bills = snapshot?.toObjects(Bill::class.java) ?: emptyList()
                callback(bills)
            }
    }

//
//    @Query("SELECT * FROM bill_table WHERE status = :status")
//    fun getBillsByStatus(status: Bill.BillStatus): LiveData<List<Bill>>
//
fun getBillsByStatus(status: Bill.BillStatus, callback: (List<Bill>) -> Unit) {
    FirebaseFirestore.getInstance().collection("bills")
        .whereEqualTo("status", status.name)
        .addSnapshotListener { snapshot, exception ->
            if (exception != null) {
                // Handle the error
                return@addSnapshotListener
            }
            val bills = snapshot?.toObjects(Bill::class.java) ?: emptyList()
            callback(bills)
        }
}

//    @Delete
//    suspend fun deleteBill(bill: Bill)

    fun deleteBill(billId: String, callback: (Boolean) -> Unit) {
        FirebaseFirestore.getInstance().collection("bills").document(billId)
            .delete()
            .addOnSuccessListener {
                callback(true)
            }
            .addOnFailureListener {
                callback(false)
            }
    }

//
//    @Update
//    suspend fun updateBill(bill: Bill)
//
fun updateBill(bill: Bill, callback: (Boolean) -> Unit) {
    FirebaseFirestore.getInstance().collection("bills").document(bill.id)
        .set(bill, SetOptions.merge())
        .addOnSuccessListener {
            callback(true)
        }
        .addOnFailureListener {
            callback(false)
        }
}

//    @Query("SELECT * FROM bill_table WHERE frequency != 'ONCE'")
//    fun getRecurringBills(): LiveData<List<Bill>>
fun getRecurringBills(callback: (List<Bill>) -> Unit) {
    FirebaseFirestore.getInstance().collection("bills")
        .whereNotEqualTo("frequency", Bill.Frequency.ONCE.name)
        .addSnapshotListener { snapshot, exception ->
            if (exception != null) {
                // Handle the error
                return@addSnapshotListener
            }
            val bills = snapshot?.toObjects(Bill::class.java) ?: emptyList()
            callback(bills)
        }
}

//
//    @Query("SELECT category, SUM(amount) as totalAmount FROM bill_table GROUP BY category")
//    fun getCategoryWiseTotalAmounts(): LiveData<List<CategoryTotalAmount>>
fun getCategoryWiseTotalAmounts(callback: (Map<String, Int>) -> Unit) {
    FirebaseFirestore.getInstance().collection("bills")
        .get()
        .addOnSuccessListener { result ->
            val categoryTotals = mutableMapOf<String, Int>()
            for (document in result) {
                val bill = document.toObject(Bill::class.java)
                categoryTotals[bill.category] = categoryTotals.getOrDefault(bill.category, 0) + bill.amount
            }
            callback(categoryTotals)
        }
        .addOnFailureListener { exception ->
            // Handle the error
        }
}

//
//    @Query("SELECT * FROM bill_table WHERE dueDate BETWEEN :startDate AND :endDate")
//    fun getBillsInRange(startDate: Long, endDate: Long): LiveData<List<Bill>>
fun getBillsInRange(startDate: Long, endDate: Long, callback: (List<Bill>) -> Unit) {
    FirebaseFirestore.getInstance().collection("bills")
        .whereGreaterThanOrEqualTo("dueDate", startDate)
        .whereLessThanOrEqualTo("dueDate", endDate)
        .addSnapshotListener { snapshot, exception ->
            if (exception != null) {
                // Handle the error
                return@addSnapshotListener
            }
            val bills = snapshot?.toObjects(Bill::class.java) ?: emptyList()
            callback(bills)
        }
}

//
//    @Query("SELECT * FROM bill_table WHERE dueDate <= :currentTime AND status = 'PENDING'")
//    fun getBillsWithOverdueDueDate(currentTime: Long): LiveData<List<Bill>>

    fun getBillsWithOverdueDueDate(currentTime: Long, callback: (List<Bill>) -> Unit) {
        FirebaseFirestore.getInstance().collection("bills")
            .whereLessThanOrEqualTo("dueDate", currentTime)
            .whereEqualTo("status", Bill.BillStatus.OVERDUE)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    // Handle the error
                    return@addSnapshotListener
                }
                val bills = snapshot?.toObjects(Bill::class.java) ?: emptyList()
                callback(bills)
            }
    }



}
