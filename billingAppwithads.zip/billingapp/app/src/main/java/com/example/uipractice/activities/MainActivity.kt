package com.example.uipractice.activities

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import com.example.uipractice.R
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.databinding.ActivityMainBinding
import com.example.uipractice.fragments.BillDetailsDialog
import com.example.uipractice.viewmodel.BillViewModel
import com.google.android.gms.ads.MobileAds
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity(), BillDetailsDialog.BillDetailsDialogListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var billViewModel: BillViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Initialize the Mobile Ads SDK
        MobileAds.initialize(this) { initializationStatus -> }

        // Initialize ViewModel
        billViewModel = ViewModelProvider(this).get(BillViewModel::class.java)


//        val adView: AdView = findViewById(R.id.adView)
//        val adRequest = AdRequest.Builder().build()
//        adView.loadAd(adRequest)

        // Set up navigation and UI listeners
        setupNavigation()

    }

    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.nav_view)

        // Set listener for bottom navigation items
        bottomNavigationView.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.homeFragment -> navController.navigate(R.id.homeFragment)
                R.id.allFilesFragment -> navController.navigate(R.id.allFilesFragment)
                R.id.reportFragment -> navController.navigate(R.id.reportFragment)
                R.id.profileFragment -> navController.navigate(R.id.profileFragment)
            }
            true
        }

        // Set listener for FloatingActionButton
        val fab = findViewById<FloatingActionButton>(R.id.fab)
        fab.setOnClickListener {
            // Navigate to CreateFragment when FAB is clicked
            navController.navigate(R.id.action_global_createFragment)
        }
    }

    fun addBill(bill: Bill) {
        billViewModel.insertBill(bill)
    }

    override fun onNavigateToScanFragment() {
        try {
            val navController = findNavController(R.id.nav_host_fragment)
            navController.navigate(R.id.action_billDetailsDialog_to_scanFragment)
        } catch (e: IllegalArgumentException) {
            Log.e("NavigationError", "Navigation action not found: ${e.message}")
        }
    }
}
