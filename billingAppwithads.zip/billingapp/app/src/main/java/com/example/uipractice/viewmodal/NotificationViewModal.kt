package com.example.uipractice.viewmodal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.uipractice.Repository.NotificationRepository
import com.example.uipractice.dataClasses.Notification
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch

class NotificationViewModel : ViewModel() {

    private val notificationRepository = NotificationRepository()

    fun getAllNotifications(): Flow<List<Notification>> = flow {
        emit(notificationRepository.getAllNotifications())
    }

    suspend fun getNotificationById(id: String): Notification? {
        return notificationRepository.getNotificationById(id)
    }

    fun insertNotification(notification: Notification) {
        viewModelScope.launch {
            notificationRepository.insert(notification)
        }
    }
}
