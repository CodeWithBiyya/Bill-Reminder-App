package com.example.uipractice.ads

import android.content.Context
import android.widget.Toast
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.AdListener

object AdManager {


    fun initializeAds(context: Context) {
        MobileAds.initialize(context) { }
    }

    fun loadAndShowAd(adView: AdView) {
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() {
                // Ad loaded successfully
                Toast.makeText(adView.context, "Ad loaded successfully", Toast.LENGTH_SHORT).show()
            }

             fun onAdFailedToLoad(adError: com.google.android.gms.ads.AdError) {
                // Handle the error
                Toast.makeText(adView.context, "Failed to load ad: ${adError.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
