package com.example.uipractice.viewmodal

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.dataClasses.Category
import com.example.uipractice.dataClasses.CategoryTotalAmount
import com.example.uipractice.repository.BillRepository
import com.example.uipractice.Repository.CategoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val billRepository = BillRepository() // Firebase-backed repository for bills
    private val categoryRepository = CategoryRepository() // Firebase-backed repository for categories

    private val _bills = MutableLiveData<List<Bill>>()
    val bills: LiveData<List<Bill>> get() = _bills

    private val _categories = MutableLiveData<List<Category>>()
    val categories: LiveData<List<Category>> get() = _categories

    private val _categoryWiseAmounts = MutableLiveData<List<CategoryTotalAmount>>() // Category-wise totals placeholder
    val categoryWiseAmounts: LiveData<List<CategoryTotalAmount>> get() = _categoryWiseAmounts

    // Function to add a category (Firebase insertion)
    fun addCategory(category: Category) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = categoryRepository.insert(category)
            if (success) {
                fetchCategories() // Refresh categories after adding a new one
            }
        }
    }

    // Fetch all bills from Firebase
    fun fetchBills() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val fetchedBills = billRepository.getAllBills()
                withContext(Dispatchers.Main) {
                    _bills.value = fetchedBills
                }
            } catch (e: Exception) {
                // Handle any errors
                withContext(Dispatchers.Main) {
                    _bills.value = emptyList()
                }
            }
        }
    }

    // Fetch all categories from Firebase
    fun fetchCategories() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val fetchedCategories = categoryRepository.getAllCategories()
                withContext(Dispatchers.Main) {
                    _categories.value = fetchedCategories
                }
            } catch (e: Exception) {
                // Handle any errors
                withContext(Dispatchers.Main) {
                    _categories.value = emptyList()
                }
            }
        }
    }

    // Fetch category-wise total amounts (this needs to be adapted for Firebase or handled on the client-side)
    fun fetchCategoryWiseAmounts() {
        // Firebase doesn't support direct aggregate queries, so this might need to be calculated client-side
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val fetchedBills = billRepository.getAllBills()
                val amounts = calculateCategoryWiseAmounts(fetchedBills)
                withContext(Dispatchers.Main) {
                    _categoryWiseAmounts.value = amounts
                }
            } catch (e: Exception) {
                // Handle any errors
                withContext(Dispatchers.Main) {
                    _categoryWiseAmounts.value = emptyList()
                }
            }
        }
    }

    // Helper function to calculate category-wise amounts from a list of bills
    private fun calculateCategoryWiseAmounts(bills: List<Bill>): List<CategoryTotalAmount> {
        val categoryTotals = mutableMapOf<String, Double>()

        for (bill in bills) {
            val category = bill.category
            val amount = bill.amount
            categoryTotals[category] = categoryTotals.getOrDefault(category, 0.0) + amount
        }

        return categoryTotals.map { (category, total) ->
            CategoryTotalAmount(category, total.toInt())
        }
    }
}
