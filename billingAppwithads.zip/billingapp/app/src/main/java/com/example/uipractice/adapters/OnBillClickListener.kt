package com.example.uipractice.adapters

import com.example.uipractice.dataClasses.Bill

interface OnBillClickListener {
    fun onBillClicked(bill: Bill)
}
