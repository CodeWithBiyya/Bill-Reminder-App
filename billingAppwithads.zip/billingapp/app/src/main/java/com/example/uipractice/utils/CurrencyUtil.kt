package com.example.uipractice.utils

object CurrencyUtil {

    private val exchangeRates = mapOf(
        "Dollar ($)" to 1.0,
        "Euro (€)" to 0.85,
        "Rupees (Rs)" to 74.0,
        "GPB (£)" to 0.75
    )

    fun convertToSelectedCurrency(amountInUSD: Double, selectedCurrency: String): Double {
        val rate = exchangeRates[selectedCurrency] ?: 1.0
        return amountInUSD * rate
    }
}
