package com.example.uipractice.fragments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.uipractice.R

class ScanFragment : Fragment() {

    private lateinit var backArrow: ImageButton
    private lateinit var helloTextView: TextView
    private lateinit var exampleImageView: ImageView
    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var textView1: TextView
    private lateinit var textView2: TextView

    private val REQUEST_SELECT_IMAGE_IN_ALBUM = 2

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_scan, container, false)

        // Initialize UI elements
        backArrow = view.findViewById(R.id.back_arrow)
        exampleImageView = view.findViewById(R.id.exampleImageView)
        helloTextView = view.findViewById(R.id.helloTextView)
        button1 = view.findViewById(R.id.button1)
        button2 = view.findViewById(R.id.button2)
        textView1 = view.findViewById(R.id.textView1)
        textView2 = view.findViewById(R.id.textView2)


        val sharedPref = activity?.getSharedPreferences("UserInfo", Context.MODE_PRIVATE)
        val name = sharedPref?.getString("name", "Name not set")

        // Set the username in helloTextView (Assuming you have the username available)
        helloTextView.text = "Hello, $name"

        // Set click listeners
        backArrow.setOnClickListener {
            // Handle back button click
            // You might want to navigate back to the previous fragment or activity
            requireActivity().onBackPressed()
        }

        button1.setOnClickListener {
            findNavController().navigate(R.id.action_scanFragment_to_cameraFragment)

        }

        button2.setOnClickListener {
            // Handle gallery button click
            selectImageFromGallery()        }

        return view
    }
    private fun selectImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_SELECT_IMAGE_IN_ALBUM)
    }
}
