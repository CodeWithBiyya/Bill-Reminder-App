// CurrencyDatabaseHelper.kt
package com.example.uipractice.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.uipractice.dataClasses.Currency

class CurrencyDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "currency.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "currencies"
        private const val COLUMN_ID = "id"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_SYMBOL = "symbol"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = """
            CREATE TABLE $TABLE_NAME (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_NAME TEXT,
                $COLUMN_SYMBOL TEXT
            )
        """.trimIndent()
        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertCurrency(currency: Currency): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues().apply {
            put(COLUMN_NAME, currency.name)
            put(COLUMN_SYMBOL, currency.symbol)
        }
        return db.insert(TABLE_NAME, null, contentValues)
    }

    // Method to retrieve all currencies
    fun getAllCurrencies(): List<Currency> {
        val db = this.readableDatabase
        val cursor = db.query(TABLE_NAME, null, null, null, null, null, null)
        val currencies = mutableListOf<Currency>()
        with(cursor) {
            while (moveToNext()) {
                val id = getLong(getColumnIndexOrThrow(COLUMN_ID))
                val name = getString(getColumnIndexOrThrow(COLUMN_NAME))
                val symbol = getString(getColumnIndexOrThrow(COLUMN_SYMBOL))
                currencies.add(Currency(id, name, symbol))
            }
        }
        cursor.close()
        return currencies
    }

    // Method to retrieve currency by name from the database

}
