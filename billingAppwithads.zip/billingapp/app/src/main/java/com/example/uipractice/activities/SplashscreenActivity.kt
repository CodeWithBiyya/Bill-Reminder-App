package com.example.uipractice.activities

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.uipractice.databinding.ActivitySplashscreenBinding
import android.content.Intent
import com.example.uipractice.R
import com.example.uipractice.ads.AdManager
import com.google.android.gms.ads.AdView

class SplashscreenActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashscreenBinding
    private lateinit var adView: AdView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashscreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AdManager.initializeAds(this)

        adView = findViewById(R.id.adView)

        // Set initial visibility of get started button to GONE
        binding.getStartedButton
            .visibility = View.GONE

        binding.getStartedButton.setOnClickListener {

            AdManager.loadAndShowAd(adView)

            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        // Animate app icon and app name
        animateAppIconAndName( binding.appIcon, binding.appName)

        // Show get started button after 4 seconds
        Handler(Looper.getMainLooper()).postDelayed({
            binding.getStartedButton.visibility = View.VISIBLE
        }, 3000)
    }

    private fun animateAppIconAndName(appIcon: View, appName: View) {
        val animatorSet = AnimatorSet()

        // Animate app icon
        val iconAnimator = ObjectAnimator.ofFloat(appIcon, "translationY", -100f, 0f)
        iconAnimator.duration = 2000
        iconAnimator.startDelay = 500
        animatorSet.play(iconAnimator)

        // Animate app name
        val nameAnimator = ObjectAnimator.ofFloat(appName, "alpha", 0f, 1f)
        nameAnimator.duration = 3000
        nameAnimator.startDelay = 1000
        animatorSet.play(nameAnimator)

        animatorSet.start()
    }
}