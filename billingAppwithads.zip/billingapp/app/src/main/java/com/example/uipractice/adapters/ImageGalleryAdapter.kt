package com.example.uipractice.adapters

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.uipractice.databinding.ItemImageBinding
import com.squareup.picasso.Picasso

class ImageGalleryAdapter(
    private val imageList: List<String>,
    private val onImageClick: (position: Int, isSelected: Boolean) -> Unit
) : RecyclerView.Adapter<ImageGalleryAdapter.ImageViewHolder>() {

    private val selectedPositions = mutableSetOf<Int>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val binding = ItemImageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ImageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        val imageUri = imageList[position]
        Picasso.get().load(Uri.parse(imageUri)).into(holder.binding.imageView)

        holder.itemView.setOnClickListener {
            val isSelected = selectedPositions.contains(position)
            if (isSelected) {
                selectedPositions.remove(position)
            } else {
                selectedPositions.add(position)
            }
            onImageClick(position, !isSelected)
            notifyItemChanged(position)
        }

        holder.itemView.isSelected = selectedPositions.contains(position)
    }

    override fun getItemCount(): Int = imageList.size

    fun getSelectedImages(): List<String> {
        return selectedPositions.map { imageList[it] }
    }

    fun clearSelections() {
        selectedPositions.clear()
        notifyDataSetChanged()
    }

    inner class ImageViewHolder(val binding: ItemImageBinding) : RecyclerView.ViewHolder(binding.root)
}
