package com.example.uipractice.fragments

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.uipractice.utils.CurrencyUtil
import com.example.uipractice.R
import com.example.uipractice.adapters.CategoryAdapter
import com.example.uipractice.adapters.Expense
import com.example.uipractice.adapters.ExpenseAdapter
import com.example.uipractice.database.FirestoreDatabase
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.dataClasses.Category
import com.example.uipractice.databinding.FragmentReportsBinding
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ReportFragment : Fragment() {

    private var _binding: FragmentReportsBinding? = null
    private val binding get() = _binding!!
    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var expenseAdapter: ExpenseAdapter
    private val firestore = FirestoreDatabase.getDatabase().db

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReportsBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.imageView.setOnClickListener {
            requireActivity().onBackPressed()
        }

        val currencySymbol = getSelectedCurrencySymbol(requireContext())
        expenseAdapter = ExpenseAdapter(emptyList(), currencySymbol)
        binding.expenseList.layoutManager = LinearLayoutManager(context)
        binding.expenseList.adapter = expenseAdapter

        categoryAdapter = CategoryAdapter { category ->
            val bundle = Bundle().apply {
                putString("categoryName", category.name)
            }
            if (category.name == "Create") {
                findNavController().navigate(R.id.action_reportFragment_to_createCategoryFragment)
            } else {
                findNavController().navigate(R.id.action_reportFragment_to_categoryDetailsFragment, bundle)
            }
        }

        binding.recyclerViewCategories.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerViewCategories.adapter = categoryAdapter

        setupArrows()
        loadExpenses()
        setupBarChart()
        setupPieChart()
        loadCategoriesFromFirestore() // Fetch categories from Firestore
    }

    private fun loadCategoriesFromFirestore() {
        firestore.collection("categories")
            .get()
            .addOnSuccessListener { result ->
                val categories = result.map { document ->
                    val category = document.toObject(Category::class.java)
                    Category(
                        id = category.id,
                        name = category.name,
                        logoResourceId = category.logoResourceId
                    )
                }
                categoryAdapter.submitList(categories) // Submit fetched categories to adapter
            }
            .addOnFailureListener { exception ->
                // Handle the error appropriately
            }
    }

    private fun getSelectedCurrencySymbol(context: Context): String {
        val sharedPreferences = context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("selected_currency_symbol", "$") ?: "$"
    }

    private fun setupBarChart() {
        val barChart: BarChart = binding.barChart

        // Initialize entries list
        val entries = mutableListOf<BarEntry>()
        val categoryNames = mutableListOf<String>()

        // Get selected currency
        val currencyManager = CurrencyManager(requireContext())
        val selectedCurrency = currencyManager.getSelectedCurrency()

        // Fetch category total amounts from Firestore
        firestore.collection("bills")
            .get()
            .addOnSuccessListener { result ->
                val categoryTotals = result.toObjects(Bill::class.java)
                entries.clear() // Clear previous entries
                var index = 0
                categoryTotals.groupBy { it.category }.forEach { (category, bills) ->
                    val totalAmount = bills.sumOf { it.amount?.toDouble() ?: 0.0 }
                    val convertedAmount = CurrencyUtil.convertToSelectedCurrency(totalAmount, selectedCurrency)

                    entries.add(BarEntry(index.toFloat(), convertedAmount.toFloat()))
                    categoryNames.add(category) // Add the category name for X-axis labels
                    index++ // Increment the index for numeric positioning
                }

                if (entries.isNotEmpty()) {
                    val dataSet = BarDataSet(entries, "Amount in $selectedCurrency")
                    dataSet.color = Color.parseColor("#FFA500")
                    dataSet.valueTextColor = Color.WHITE
                    dataSet.valueTextSize = 12f

                    val barData = BarData(dataSet)
                    barChart.data = barData
                    barChart.invalidate() // Refresh the chart
                } else {
                    barChart.clear()
                }
            }
            .addOnFailureListener {
                // Handle errors, if any
            }

        // Customize X-axis
        val xAxis = barChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.setDrawGridLines(false)
        xAxis.textColor = Color.WHITE
        xAxis.valueFormatter = IndexAxisValueFormatter(categoryNames) // Use category names for X-axis labels
        xAxis.labelCount = categoryNames.size
        xAxis.granularity = 1f

        // Customize Y-axis
        val leftAxis = barChart.axisLeft
        leftAxis.textColor = Color.WHITE
        leftAxis.setDrawGridLines(false)
        leftAxis.axisMinimum = 0f // Start at zero

        val rightAxis = barChart.axisRight
        rightAxis.isEnabled = false

        // Other customizations
        barChart.legend.isEnabled = false
        barChart.description.isEnabled = false
    }

    @SuppressLint("SetTextI18n")
    private fun setupPieChart() {
        val pieChart: PieChart = binding.pieChart
        val totalPriceTextView: TextView = binding.totalBillsAmount

        // Define a map of category names to colors
        val categoryColors = mapOf(
            "House Rent" to "#BD0E01", // Red
            "Gas" to "#FFD700", // Yellow
            "Electricity" to "#7E57C2", // Purple
            "Television" to "#1E90FF", // Dodger Blue
            "Water" to "#00CED1", // Dark Turquoise
            "Garbage" to "#8B4513", // Saddle Brown
            "Credit Card" to "#DC143C", // Crimson
            "Medicine" to "#32CD32", // Lime Green
            "Internet" to "#4B0082", // Indigo
            "Travel" to "#FF8A80",
            "Insurance" to "#ADD8E6",
            "Mobile" to "#FF8D62"
        )

        // Fetch category total amounts from Firestore
        firestore.collection("bills")
            .get()
            .addOnSuccessListener { result ->
                val categoryTotals = result.toObjects(Bill::class.java)
                val totalAmount = categoryTotals.sumOf { it.amount.toDouble() }

                if (totalAmount > 0) {
                    val entries = mutableListOf<PieEntry>()
                    categoryTotals.groupBy { it.category }.forEach { (category, bills) ->
                        val amount = bills.sumOf { it.amount.toDouble() }
                        entries.add(PieEntry(amount.toFloat(), category))
                    }

                    val dataSet = PieDataSet(entries, "Categories")
                    dataSet.colors = entries.map { Color.parseColor(categoryColors[it.label] ?: "#FFFFFF") }
                    dataSet.sliceSpace = 4f
                    dataSet.selectionShift = 5f

                    val data = PieData(dataSet)

                    // Disable labels on the slices
                    dataSet.valueTextSize = 0f // Hide the value text

                    pieChart.data = data
                    pieChart.isDrawHoleEnabled = true

                    pieChart.setDrawEntryLabels(false)

                    pieChart.holeRadius = 70f // Adjust this value as needed to reduce the width of the slices
                    pieChart.transparentCircleRadius = 50f // Adjust this to control the transparent circle around the hole

                    pieChart.setHoleColor(Color.TRANSPARENT)
                    pieChart.setEntryLabelColor(Color.BLACK)
                    pieChart.animateY(1000, com.github.mikephil.charting.animation.Easing.EaseInOutQuad)

                } else {
                    pieChart.clear()
                    totalPriceTextView.text = "No data available"
                }
            }
            .addOnFailureListener {
                // Handle errors, if any
            }
    }

    private fun setupArrows() {
        // Implement arrow setup if needed
    }

    private fun loadExpenses() {
        lifecycleScope.launch {
            try {
                val expenses = fetchExpensesFromFirestore()
                expenseAdapter.submitList(expenses)
            } catch (e: Exception) {
                // Handle exceptions if needed
            }
        }
    }

    private suspend fun fetchExpensesFromFirestore(): List<Expense> {
        return suspendCancellableCoroutine { continuation ->
            firestore.collection("bills")
                .get()
                .addOnSuccessListener { result ->
                    val expenses = result.map { document ->
                        val bill = document.toObject(Bill::class.java)
                        Expense(
                            name = bill.category,
                            amount = bill.amount.toInt(),
                            colorResId = R.color.grey, // Update with appropriate resource if needed
                            iconResId = R.drawable.default_icon, // Update with appropriate resource if needed
                            progress = 0, // Set default progress if needed
                            backgroundColor = Color.WHITE // Set default background color if needed
                        )
                    }
                    continuation.resume(expenses) // Resume with fetched data
                }
                .addOnFailureListener { exception ->
                    continuation.resumeWithException(exception) // Resume with an exception
                }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
