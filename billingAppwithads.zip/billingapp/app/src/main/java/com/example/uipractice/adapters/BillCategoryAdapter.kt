package com.example.uipractice.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.uipractice.R
import com.example.uipractice.dataClasses.CategoryTotalAmount

class BillCategoryAdapter(
    private var bills: List<CategoryTotalAmount>,
    private val currencySymbol: String // Add currency symbol parameter
) : RecyclerView.Adapter<BillCategoryAdapter.BillViewHolder>() {

    class BillViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val category: TextView = view.findViewById(R.id.tvBillCategory)
        val amount: TextView = view.findViewById(R.id.tvBillAmount)
        val amountProgressBar: ProgressBar = view.findViewById(R.id.progressBill)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BillViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_billcategory, parent, false)
        return BillViewHolder(view)
    }

    override fun onBindViewHolder(holder: BillViewHolder, position: Int) {
        val bill = bills[position]
        holder.category.text = bill.category
        holder.amount.text = "$currencySymbol${bill.totalAmount}" // Use the currency symbol

        // Calculate total amount of all bills
        val totalAmount = bills.sumOf { it.totalAmount }

        // Calculate and set progress on the ProgressBar based on category amount
        val amountPercentage = getAmountPercentage(bill.totalAmount, totalAmount)
        holder.amountProgressBar.progress = amountPercentage

        // Optional: Log the percentage for debugging purposes
        Log.d("BillCategoryAdapter", "Category: ${bill.category}, Total: ${bill.totalAmount}, Total All: $totalAmount, Percentage: $amountPercentage%")
    }

    override fun getItemCount(): Int = bills.size

    fun updateBills(newBills: List<CategoryTotalAmount>) {
        bills = newBills
        notifyDataSetChanged()
        Log.d("BillCategoryAdapter", "Updated bills: $bills")
    }

    private fun getAmountPercentage(categoryAmount: Int, totalAmount: Int): Int {
        return if (totalAmount > 0) {
            (categoryAmount * 100) / totalAmount
        } else {
            0 // Return 0 if totalAmount is 0 to avoid division by zero
        }
    }
}
