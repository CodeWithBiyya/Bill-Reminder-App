package com.example.uipractice.fragments

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.uipractice.R
import com.example.uipractice.databinding.FragmentPersonalInfoBinding
import java.io.File
import java.io.IOException
import java.util.regex.Pattern

class PersonalInfoFragment : Fragment() {

    private var _binding: FragmentPersonalInfoBinding? = null
    private val binding get() = _binding!!

    private val REQUEST_IMAGE_CAPTURE = 1
    private val REQUEST_SELECT_IMAGE_IN_ALBUM = 2
    private val REQUEST_PERMISSION = 3
    private var photoURI: Uri? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPersonalInfoBinding.inflate(inflater, container, false)
        val view = binding.root

        checkPermissions()

        // Set click listeners
        binding.backArrow.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.importPhotoText.setOnClickListener {
            showPhotoOptions()
        }

        binding.chooseFromGalleryButton.setOnClickListener {
            selectImageFromGallery()
        }

        binding.chooseFromCameraButton.setOnClickListener {
            captureImageFromCamera()
        }

        binding.cancelButton.setOnClickListener {
            hidePhotoOptions()
        }

        binding.saveButton.setOnClickListener {
            val name = binding.nameEditText.text.toString()
            val email = binding.emailEditText.text.toString()

            if (validateEmail(email)) {
                // Save user details in SharedPreferences
                val sharedPref = activity?.getSharedPreferences("UserInfo", Context.MODE_PRIVATE)
                with(sharedPref?.edit()) {
                    this?.putString("name", name)
                    this?.putString("email", email)
                    this?.putString("imageUri", photoURI?.toString())
                    this?.apply()
                }

                // Navigate to ProfileFragment
                findNavController().navigate(R.id.action_personalInfoFragment_to_profileFragment)
            } else {
                Toast.makeText(requireContext(), "Invalid email address", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }

    private fun validateEmail(email: String): Boolean {
        val emailPattern = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@gmail\\.com$"
        )
        return emailPattern.matcher(email).matches()
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                REQUEST_PERMISSION
            )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
            } else {
                // Permission denied
                Toast.makeText(requireContext(), "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun selectImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_SELECT_IMAGE_IN_ALBUM)
    }

    private fun captureImageFromCamera() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(requireActivity().packageManager) != null) {
            try {
                val photoFile = createImageFile()
                photoURI = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", photoFile)
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
            } catch (ex: IOException) {
                Log.e("PersonalInfoFragment", "Error creating file for image capture: ${ex.message}")
            }
        } else {
            Log.e("PersonalInfoFragment", "captureImageFromCamera: No camera activity found")
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val fileName = "JPEG_" + System.currentTimeMillis() + "_"
        val storageDir: File = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            fileName,
            ".jpg",
            storageDir
        )
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_SELECT_IMAGE_IN_ALBUM -> {
                    val selectedImageUri: Uri? = data?.data
                    if (selectedImageUri != null) {
                        try {
                            val inputStream = requireContext().contentResolver.openInputStream(selectedImageUri)
                            binding.selectedImageView.setImageURI(selectedImageUri)
                            photoURI = selectedImageUri
                        } catch (e: Exception) {
                            Log.e("PersonalInfoFragment", "Error loading image: ${e.message}")
                        }
                    }
                }
                REQUEST_IMAGE_CAPTURE -> {
                    photoURI?.let {
                        binding.selectedImageView.setImageURI(it)
                    }
                }
            }
        }
    }

    private fun showPhotoOptions() {
        binding.chooseFromGalleryButton.visibility = View.VISIBLE
        binding.chooseFromCameraButton.visibility = View.VISIBLE
        binding.cancelButton.visibility = View.VISIBLE
    }

    private fun hidePhotoOptions() {
        binding.chooseFromGalleryButton.visibility = View.GONE
        binding.chooseFromCameraButton.visibility = View.GONE
        binding.cancelButton.visibility = View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
