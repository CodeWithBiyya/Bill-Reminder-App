package com.example.uipractice.dao

import androidx.room.Dao
import com.example.uipractice.dataClasses.Category
import com.google.firebase.firestore.FirebaseFirestore

@Dao
interface CategoryDao {
//    @Query("SELECT * FROM category_table")
//    fun getAllCategories(): List<Category>

    fun getAllCategories(callback: (List<Category>) -> Unit) {
        FirebaseFirestore.getInstance().collection("categories")
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    // Handle the error
                    return@addSnapshotListener
                }
                val categories = snapshot?.toObjects(Category::class.java) ?: emptyList()
                callback(categories)
            }
    }

//    @Insert
//    suspend fun insert(category: Category)

    fun insert(category: Category, callback: (Boolean) -> Unit) {
        FirebaseFirestore.getInstance().collection("categories").document(category.id.toString())
            .set(category)
            .addOnSuccessListener {
                callback(true)
            }
            .addOnFailureListener {
                callback(false)
            }
    }
}
