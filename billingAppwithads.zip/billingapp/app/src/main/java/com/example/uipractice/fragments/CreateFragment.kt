package com.example.uipractice.fragments

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.DatePicker
import android.widget.ImageView
import android.widget.Switch
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.uipractice.R
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.databinding.FragmentCreateBinding
import com.example.uipractice.viewmodel.BillViewModel
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import java.util.*

class CreateFragment : Fragment(), DatePickerDialog.OnDateSetListener {

    private var _binding: FragmentCreateBinding? = null
    private val binding get() = _binding!!
    private lateinit var billViewModel: BillViewModel
    private lateinit var switchRepeat: Switch
    private lateinit var firestore: FirebaseFirestore
    private var mInterstitialAd: InterstitialAd? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCreateBinding.inflate(inflater, container, false)
        return binding.root
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        billViewModel = ViewModelProvider(this).get(BillViewModel::class.java)

        firestore = FirebaseFirestore.getInstance()

        val imageView = view.findViewById<ImageView>(R.id.imageView)
        imageView.setOnClickListener {
            findNavController().navigate(R.id.action_createFragment_to_homeFragment)
        }

        val categories = resources.getStringArray(R.array.categories_array)
        val categoryAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories)
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerCategory.adapter = categoryAdapter

        val frequencies = resources.getStringArray(R.array.frequency_array)
        val frequencyAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, frequencies)
        frequencyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerFrequency.adapter = frequencyAdapter

        switchRepeat = binding.root.findViewById(R.id.switch_repeat)

        binding.tvDueDate.setOnClickListener {
            showDateTimePicker { dateTimeInMillis ->
                if (dateTimeInMillis > System.currentTimeMillis()) {
                    val formattedDate = formatDateTime(dateTimeInMillis)
                    binding.tvDueDate.text = formattedDate
                    binding.tvDueDate.tag = dateTimeInMillis
                } else {
                    Toast.makeText(requireContext(), "Selected date is in the past", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.tvReminderTime.setOnClickListener {
            showDateTimePicker { reminderTimeInMillis ->
                val formattedDate = formatDateTime(reminderTimeInMillis)
                binding.tvReminderTime.text = formattedDate
                binding.tvReminderTime.tag = reminderTimeInMillis
            }
        }

        binding.editTextAmount.inputType = android.text.InputType.TYPE_CLASS_NUMBER

        loadInterstitialAd()

        binding.btnCreate.setOnClickListener {
            val description = binding.editTextDescription.text.toString().trim()
            val dueDate = binding.tvDueDate.text.toString()
            val category = binding.spinnerCategory.selectedItem.toString()
            val reminderTimeInMillis = binding.tvReminderTime.tag as? Long
            val amountStr = binding.editTextAmount.text.toString().trim()
            val frequencySelected = binding.spinnerFrequency.selectedItem.toString()

            if (description.isNotEmpty() && dueDate.isNotEmpty() &&
                category.isNotEmpty() && frequencySelected.isNotEmpty() && reminderTimeInMillis != null &&
                amountStr.isNotEmpty()) {

                val selectedCurrency = getSelectedCurrency()
                val amountInUSD = amountStr.toDouble()
                val convertedAmount = convertAmountToSelectedCurrency(amountInUSD, selectedCurrency)

                val frequency = if (switchRepeat.isChecked) {
                    Bill.Frequency.valueOf(frequencySelected.uppercase())
                } else {
                    Bill.Frequency.ONCE
                }

                val status = if (switchRepeat.isChecked) {
                    Bill.BillStatus.RECURRING
                } else {
                    Bill.BillStatus.UPCOMING
                }

                val bill = Bill(
                    description = description,
                    dueDate = dueDate,
                    category = category,
                    frequency = frequency,
                    reminderTime = reminderTimeInMillis,
                    amount = convertedAmount.toInt(),
                    status = status
                )

                if (mInterstitialAd != null) {
                    mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            saveBillToFirestore(bill)
                            Log.d("CreateFragment", "Ad dismissed.")
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                            saveBillToFirestore(bill)
                            Log.e("CreateFragment", "Ad failed to show: ${adError.message}")
                        }

                        override fun onAdShowedFullScreenContent() {
                            mInterstitialAd = null
                        }
                    }
                    mInterstitialAd?.show(requireActivity())
                } else {
                    saveBillToFirestore(bill)
                }
            } else {
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showDateTimePicker(onDateTimeSet: (Long) -> Unit) {
        val calendar = Calendar.getInstance()
        val currentYear = calendar.get(Calendar.YEAR)
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentDay = calendar.get(Calendar.DAY_OF_MONTH)
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMinute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(
            requireContext(),
            { _, hour, minute ->
                val datePickerDialog = DatePickerDialog(
                    requireContext(),
                    { _, year, month, day ->
                        val selectedDate = Calendar.getInstance()
                        selectedDate.set(year, month, day, hour, minute)

                        onDateTimeSet(selectedDate.timeInMillis)
                    },
                    currentYear,
                    currentMonth,
                    currentDay
                )
                datePickerDialog.show()
            },
            currentHour,
            currentMinute,
            false
        )
        timePickerDialog.show()
    }

    private fun formatDateTime(timeInMillis: Long): String {
        val calendar = Calendar.getInstance().apply {
            setTimeInMillis(timeInMillis)
        }
        return String.format(
            "%02d:%02d %02d/%02d/%04d",
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.YEAR)
        )
    }

    private fun loadInterstitialAd() {
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(requireContext(), "your-ad-unit-id", adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    mInterstitialAd = interstitialAd
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    mInterstitialAd = null
                }
            })
    }

    private fun convertAmountToSelectedCurrency(amountInUSD: Double, selectedCurrency: String): Double {
        val conversionRates = mapOf(
            "USD" to 1.0,
            "EUR" to 0.85,
            "INR" to 75.0,
            "GBP" to 0.75,
            "PKR" to 300.0
        )
        return amountInUSD * (conversionRates[selectedCurrency] ?: 1.0)
    }

    private fun getSelectedCurrency(): String {
        val sharedPreferences = requireContext().getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("selected_currency", "USD") ?: "USD"
    }

    private fun saveBillToFirestore(bill: Bill) {
        val billCollection = firestore.collection("bills")
        val documentRef = billCollection.document()

        val billMap = hashMapOf(
            "description" to bill.description,
            "dueDate" to bill.dueDate,
            "category" to bill.category,
            "frequency" to bill.frequency.name,
            "reminderTime" to bill.reminderTime,
            "amount" to bill.amount,
            "status" to bill.status.name
        )

        documentRef.set(billMap, SetOptions.merge())
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Bill created and saved to Firestore", Toast.LENGTH_SHORT).show()
                Log.d("CreateFragment", "Bill saved to Firestore: $billMap")
                findNavController().navigateUp()
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Failed to save bill to Firestore", Toast.LENGTH_SHORT).show()
                Log.e("CreateFragment", "Error saving bill to Firestore", e)
            }
    }

    override fun onDateSet(view: DatePicker, year: Int, month: Int, dayOfMonth: Int) {
        val selectedDate = "$dayOfMonth/${month + 1}/$year"
        binding.tvDueDate.text = selectedDate
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
