package com.example.uipractice.dataClasses

data class CategoryTotalAmount(
    val category: String = "",
    val totalAmount: Int = 0
)

