package com.example.uipractice.Repository

import com.example.uipractice.dataClasses.Notification
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class NotificationRepository {

    private val db = FirebaseFirestore.getInstance()
    private val collection = db.collection("notifications")

    suspend fun getNotificationsForCurrentTime(currentTime: Long): List<Notification> {
        return try {
            val snapshot = collection.whereLessThanOrEqualTo("timestamp", currentTime).get().await()
            snapshot.toObjects(Notification::class.java)
        } catch (e: Exception) {
            // Handle the exception
            emptyList()
        }
    }

    suspend fun getNotificationById(documentId: String): Notification? {
        return try {
            val documentSnapshot = collection.document(documentId).get().await()
            documentSnapshot.toObject(Notification::class.java)
        } catch (e: Exception) {
            // Handle the exception
            null
        }
    }

    suspend fun getAllNotifications(): List<Notification> {
        return try {
            val snapshot = collection.get().await()
            snapshot.toObjects(Notification::class.java)
        } catch (e: Exception) {
            // Handle the exception
            emptyList()
        }
    }

    suspend fun insert(notification: Notification): Boolean {
        return try {
            val documentRef = collection.add(notification).await()
            documentRef.id.isNotEmpty()  // Return true if the document was added
        } catch (e: Exception) {
            // Handle the exception
            false
        }
    }

    suspend fun delete(documentId: String): Boolean {
        return try {
            collection.document(documentId).delete().await()
            true
        } catch (e: Exception) {
            // Handle the exception
            false
        }
    }
}
