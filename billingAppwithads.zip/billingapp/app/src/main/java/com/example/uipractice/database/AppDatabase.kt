package com.example.uipractice.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.uipractice.dao.BillDao
import com.example.uipractice.dao.CategoryDao
import com.example.uipractice.dao.NotificationDao
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.dataClasses.Category
import com.example.uipractice.dataClasses.Notification

@Database(entities = [Category::class, Bill::class, Notification::class], version = 8, exportSchema = false)
//@TypeConverters(Bill.Converters::class)

abstract class AppDatabase : RoomDatabase() {

    abstract fun billDao(): BillDao
    abstract fun notificationDao(): NotificationDao
    abstract fun categoryDao(): CategoryDao



    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Define the migration
        val MIGRATION_5_6 = object : Migration(5, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Example migration: adding a new column
                database.execSQL("ALTER TABLE bill_table ADD COLUMN new_column_name INTEGER NOT NULL DEFAULT 0")
            }
        }


        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                ).addMigrations(MIGRATION_5_6).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}