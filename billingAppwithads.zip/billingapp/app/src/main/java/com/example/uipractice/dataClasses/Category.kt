package com.example.uipractice.dataClasses

data class Category(
    val id: Int = 0,
    val name: String = "",
    val logoResourceId: Int = 0
)
