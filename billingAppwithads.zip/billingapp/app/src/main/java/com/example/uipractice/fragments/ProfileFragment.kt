package com.example.uipractice.fragments

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.uipractice.R
import com.example.uipractice.databinding.FragmentProfileBinding

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    companion object {
        private const val TAG = "ProfileFragment"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d(TAG, "onViewCreated: ProfileFragment created")

        // Load user info from SharedPreferences
        val sharedPref = activity?.getSharedPreferences("UserInfo", Context.MODE_PRIVATE)
        val name = sharedPref?.getString("name", "Name not set")
        val email = sharedPref?.getString("email", "Email not set")
        val imageUriString = sharedPref?.getString("imageUri", null)

        // Update TextViews
        binding.userName.text = name
        binding.userEmail.text = email

        // Display the image
       // Get the ImageView
        val imageView: ImageView = binding.userImageView

// Load image using Glide
        if (imageUriString != null) {
            val imageUri = Uri.parse(imageUriString)
            Glide.with(this)
                .load(imageUri) // Load the image from the URI
                .apply(RequestOptions.circleCropTransform()) // Apply circular crop transformation
                .placeholder(R.drawable.ic_person) // Placeholder if loading
                .error(R.drawable.ic_person) // Error image if loading fails
                .into(imageView)
        } else {
            // Load default image if no URI is found
            Glide.with(this)
                .load(R.drawable.ic_person) // Load the default image
                .apply(RequestOptions.circleCropTransform()) // Apply circular crop transformation
                .into(imageView)
        }


        // Setting click listeners for navigation
        binding.editIcon.setOnClickListener {
            findNavController().navigate(R.id.action_profileFragment_to_personalInfoFragment)
        }

        binding.personalInfo.setOnClickListener {
            Log.i(TAG, "Personal Info clicked")
            findNavController().navigate(R.id.action_profileFragment_to_personalInfoFragment)
        }

        binding.categories.setOnClickListener {
            Log.i(TAG, "Categories clicked")
            findNavController().navigate(R.id.action_profileFragment_to_categoriesFragment)
        }

        binding.currencies.setOnClickListener {
            Log.i(TAG, "Currencies clicked")
            findNavController().navigate(R.id.action_profileFragment_to_currencyFragment)
        }

        binding.calendar.setOnClickListener {
            Log.i(TAG, "Calendar clicked")
            findNavController().navigate(R.id.action_profileFragment_to_calenderFragment)
        }

        binding.privacyPolicy.setOnClickListener {
            Log.i(TAG, "Privacy Policy clicked")
            findNavController().navigate(R.id.action_profileFragment_to_privacyPolicyFragment)
        }

        binding.feedback.setOnClickListener {
            Log.i(TAG, "Feedback clicked")
            findNavController().navigate(R.id.action_profileFragment_to_feedbackFragment)
        }

        binding.rateUs.setOnClickListener {
            Log.i(TAG, "Rate Us clicked")
            findNavController().navigate(R.id.action_profileFragment_to_rateUsFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d(TAG, "onDestroyView: ProfileFragment destroyed")
        _binding = null
    }
}
