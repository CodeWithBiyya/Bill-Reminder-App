package com.example.uipractice.dataClasses

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Bill(
    var id: String ="", // Firestore document ID (use Firestore-generated ID or custom)
    val description: String = "",
    val dueDate: String = "", // Can be stored as a timestamp if needed
    val category: String = "",
    val frequency: Frequency = Frequency.ONCE,
    val reminderTime: Long = 0L,
    val amount: Int = 0,
    var isPaid: Boolean = false,
    var status: BillStatus = BillStatus.UPCOMING
) : Parcelable {

    enum class BillStatus {
        PAID,
        UPCOMING,
        RECURRING,
        OVERDUE
    }

    enum class Frequency {
        ONCE,
        DAILY,
        WEEKLY,
        MONTHLY,
        YEARLY
    }
}
