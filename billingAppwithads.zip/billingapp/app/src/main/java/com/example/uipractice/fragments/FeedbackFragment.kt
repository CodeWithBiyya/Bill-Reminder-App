package com.example.uipractice.fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.uipractice.databinding.FragmentFeedbackBinding

class FeedbackFragment : Fragment() {

    private var _binding: FragmentFeedbackBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment using view binding
        _binding = FragmentFeedbackBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Handle submit button click
        binding.submitButton.setOnClickListener {
            val feedback = binding.feedbackInput.text.toString()
            val name = binding.nameInput.text.toString()
            val email = binding.emailInput.text.toString()

            if (feedback.isNotEmpty() && name.isNotEmpty() && email.isNotEmpty()) {
                // Show a message to the user
                Toast.makeText(requireContext(), "Thank you for your feedback!", Toast.LENGTH_LONG).show()

                // Redirect to the Play Store for feedback
                openPlayStoreReview()
            } else {
                Toast.makeText(requireContext(), "Please enter all details", Toast.LENGTH_SHORT).show()
            }
        }

        // Handle cancel button click
        binding.cancelButton.setOnClickListener {
            // Clear all input fields
            binding.feedbackInput.text.clear()
            binding.nameInput.text.clear()
            binding.emailInput.text.clear()

            Toast.makeText(requireContext(), "Form cleared", Toast.LENGTH_SHORT).show()

            // Optionally, navigate back or close the fragment
            // requireActivity().onBackPressed()
        }

        // Handle back arrow button click
        binding.backArrow.setOnClickListener {
            requireActivity().onBackPressed()
        }
    }

    private fun openPlayStoreReview() {
        try {
            // Open the Google Play Store page for your app
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${requireContext().packageName}"))
            startActivity(intent)
        } catch (e: Exception) {
            // If Google Play Store is not installed, open the URL in a web browser
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${requireContext().packageName}"))
            startActivity(intent)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
