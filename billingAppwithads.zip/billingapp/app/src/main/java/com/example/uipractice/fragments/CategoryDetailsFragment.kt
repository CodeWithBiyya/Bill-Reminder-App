package com.example.uipractice.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.uipractice.R
import com.example.uipractice.adapters.BillAdapter
import com.example.uipractice.adapters.OnBillClickListener
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.viewmodal.CategoryDetailsViewModel

class CategoryDetailsFragment : Fragment(), OnBillClickListener {

    private lateinit var viewModel: CategoryDetailsViewModel
    private lateinit var billAdapter: BillAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_category_details, container, false)

        val categoryNameTextView = view.findViewById<TextView>(R.id.category_name)
        val recyclerViewBills = view.findViewById<RecyclerView>(R.id.recycler_view_bills)

        val categoryName = arguments?.getString("categoryName")

        categoryName?.let {
            categoryNameTextView.text = it
            // Set other category details here if needed
        }

        viewModel = ViewModelProvider(this)[CategoryDetailsViewModel::class.java]
        val currencySymbol = getSelectedCurrencySymbol(requireContext())

        billAdapter = BillAdapter (this,currencySymbol)
        recyclerViewBills.adapter = billAdapter
        recyclerViewBills.layoutManager = LinearLayoutManager(requireContext())

        categoryName?.let {
            viewModel.getBillsByCategory(it).observe(viewLifecycleOwner) { bills ->
                bills?.let {
                    println("listsiz/// ${it.size}")
                    billAdapter.submitList(it)
                }
            }
        }

        view.findViewById<ImageView>(R.id.imageView).setOnClickListener {
            findNavController().popBackStack()
        }

        return view
    }

    private fun getSelectedCurrencySymbol(context: Context): String {
        val sharedPreferences = context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("selected_currency_symbol", "$") ?: "$"
    }

    override fun onBillClicked(bill: Bill) {
        Toast.makeText(requireContext(), "Clicked on: ${bill.description}", Toast.LENGTH_SHORT)
            .show()
        val dialog = BillDetailsDialog.newInstance(bill)
        val bundle = Bundle()
        bundle.putParcelable("bill", bill) // Ensure Bill is Parcelable
        dialog.arguments = bundle
        dialog.show(parentFragmentManager, "BillDetailsDialog")
    }


}
