package com.example.uipractice.fragments

import android.content.Context
import android.graphics.Canvas
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.uipractice.R
import com.example.uipractice.adapters.BillAdapter
import com.example.uipractice.adapters.OnBillClickListener
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.databinding.FragmentBillListBinding
import com.example.uipractice.viewmodel.BillViewModel

class BillListFragment : Fragment(), OnBillClickListener {

    private var _binding: FragmentBillListBinding? = null
    private val binding get() = _binding!!
    private lateinit var billViewModel: BillViewModel
    private lateinit var billAdapter: BillAdapter
    private var status: Bill.BillStatus? = null
    private var category: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            status = it.getSerializable(ARG_STATUS) as? Bill.BillStatus
            category = it.getString(ARG_CATEGORY)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBillListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set up RecyclerView and adapter
        val currencySymbol = getSelectedCurrencySymbol(requireContext())
        billAdapter = BillAdapter(this, currencySymbol)
        binding.recyclerViewBills.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = billAdapter
        }

        // Initialize ViewModel
        billViewModel = ViewModelProvider(requireActivity()).get(BillViewModel::class.java)

        // Observe LiveData based on status or category
        when {
            status != null -> {
                billViewModel.paidBills.observe(viewLifecycleOwner) { bills ->
                    bills?.let { billAdapter.submitList(it) }
                }
            }
            category != null -> {
                billViewModel.getBillsByCategory(category!!).observe(viewLifecycleOwner) { bills ->
                    bills?.let { billAdapter.submitList(it) }
                }
            }
            else -> {
                billViewModel.upcomingBills.observe(viewLifecycleOwner) { bills ->
                    bills?.let { billAdapter.submitList(it) }
                }
            }
        }

        // Swipe to delete setup
        val swipeToDeleteCallback = SwipeToDeleteCallback(requireContext(), billAdapter) { bill ->
            billViewModel.deleteBill(bill.id) // Use bill ID to delete the bill
        }
        val itemTouchHelper = ItemTouchHelper(swipeToDeleteCallback)
        itemTouchHelper.attachToRecyclerView(binding.recyclerViewBills)

        billViewModel.loadBills() // Load bills on fragment start
    }

    private fun getSelectedCurrencySymbol(context: Context): String {
        val sharedPreferences = context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("selected_currency_symbol", "$") ?: "$"
    }

    override fun onBillClicked(bill: Bill) {
        Toast.makeText(requireContext(), "Clicked on: ${bill.description}", Toast.LENGTH_SHORT).show()

        val dialog = BillDetailsDialog.newInstance(bill)
        val bundle = Bundle()
        bundle.putParcelable("bill", bill) // Ensure Bill is Parcelable
        dialog.arguments = bundle
        dialog.show(parentFragmentManager, "BillDetailsDialog")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_STATUS = "status"
        private const val ARG_CATEGORY = "category"

        @JvmStatic
        fun newInstance(status: Bill.BillStatus): BillListFragment {
            val args = Bundle().apply {
                putSerializable(ARG_STATUS, status)
            }
            return BillListFragment().apply {
                arguments = args
            }
        }

        @JvmStatic
        fun newInstance(category: String): BillListFragment {
            val args = Bundle().apply {
                putString(ARG_CATEGORY, category)
            }
            return BillListFragment().apply {
                arguments = args
            }
        }
    }

    private inner class SwipeToDeleteCallback(
        private val context: Context,
        private val adapter: BillAdapter,
        private val onDelete: (Bill) -> Unit
    ) : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {

        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean = false

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
            val position = viewHolder.bindingAdapterPosition
            val item = adapter.currentList[position]

            // Check if the item is a Bill before casting and deleting
            if (item is Bill) {
                onDelete(item) // Call onDelete with the bill
                adapter.notifyItemRemoved(position)
            } else {
                // Handle cases where the item is not a Bill (if needed)
                adapter.notifyItemChanged(position) // Restore item if it's not a Bill
            }
        }

        override fun onChildDraw(
            c: Canvas,
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            dX: Float,
            dY: Float,
            actionState: Int,
            isCurrentlyActive: Boolean
        ) {
            val itemView = viewHolder.itemView
            val background = ContextCompat.getDrawable(context, R.drawable.swipe_background)

            // Draw background
            background?.setBounds(
                itemView.right + dX.toInt(),
                itemView.top,
                itemView.right,
                itemView.bottom
            )
            background?.draw(c)

            // Draw icon
            val icon = ContextCompat.getDrawable(context, R.drawable.garbage)
            icon?.let {
                val iconMargin = (itemView.height - it.intrinsicHeight) / 2
                val iconTop = itemView.top + iconMargin
                val iconBottom = iconTop + it.intrinsicHeight
                val iconLeft = itemView.right - it.intrinsicWidth - iconMargin
                val iconRight = itemView.right - iconMargin

                it.setBounds(iconLeft, iconTop, iconRight, iconBottom)
                it.draw(c)
            }

            super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
        }
    }
}
