package com.example.uipractice.adapters

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.uipractice.fragments.BillListFragment

class ViewPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment.requireActivity()) {
    override fun getItemCount(): Int {
        return 4
    }

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> BillListFragment.newInstance("upcoming")
            1 -> BillListFragment.newInstance("paid")
            2 -> BillListFragment.newInstance("overdue")
            3 -> BillListFragment.newInstance("recurring")
            else -> throw IllegalArgumentException("Invalid position")
        }
    }
}
