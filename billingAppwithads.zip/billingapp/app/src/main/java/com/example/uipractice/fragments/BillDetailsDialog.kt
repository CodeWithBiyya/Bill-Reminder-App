package com.example.uipractice.fragments

import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.uipractice.R
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.databinding.BillDetailsDialogBinding
import com.example.uipractice.viewmodel.BillViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class BillDetailsDialog : DialogFragment() {


    private var listener: BillDetailsDialogListener? = null

    interface BillDetailsDialogListener {
        fun onNavigateToScanFragment()
    }


    override fun onAttach(context: Context) {
        super.onAttach(context)
        listener = try {
            parentFragment as? BillDetailsDialogListener
        } catch (e: ClassCastException) {
            throw ClassCastException("$context must implement BillDetailsDialogListener")
        }
    }



    private var bill: Bill? = null
    private lateinit var billViewModel: BillViewModel
    private var fromPaid: Boolean = false

    private lateinit var binding: BillDetailsDialogBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            bill = it.getParcelable("bill")
            fromPaid = it.getBoolean("fromPaid", false)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = BillDetailsDialogBinding.inflate(inflater, container, false)
        val view = binding.root

        billViewModel = ViewModelProvider(requireActivity())[BillViewModel::class.java]

        // Get current date
        val currentDate = Calendar.getInstance().time
        val dateFormat = SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault())
        val formattedDate = dateFormat.format(currentDate)

        // Set bill details
        bill?.let {
            binding.billType.text = it.description
            binding.billAmount.text = "$${it.amount}"
            binding.billDates.text = "Created: $formattedDate - Updated: Today"
            binding.billDueDate.text = "Due Date: ${it.dueDate}"

            // Set category icon
            binding.billIcon.setImageResource(getCategoryIcon(it.category))
        }

        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)

        binding.markAsPaidButton.setOnClickListener {
            bill?.let {
                billViewModel.markAsPaid(it)
                listener?.onNavigateToScanFragment()
                              dismiss()
            }
        }
        binding.backButton.setOnClickListener {
            dismiss()
        }

        return view
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        if (fromPaid) {
            navigateToScanFragment()
        }
    }

    private fun navigateToScanFragment() {
        try {
//            val action = BillDetailsDialogDirections.actionBillDetailsDialogToScanFragment("User Name")
//            findNavController().navigate(action)
            val navController = findNavController()
            Log.d("Navigation", "Current Destination: ${navController.currentDestination?.label}")
            findNavController().navigate(R.id.action_billDetailsDialog_to_scanFragment)
        } catch (e: IllegalArgumentException) {
            Log.e("NavigationError", "Navigation action not found: ${e.message}")
            // Handle the navigation error, perhaps show a message to the user or navigate to a fallback fragment
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }


    private fun getCategoryIcon(category: String): Int {
        return when (category) {
            "House Rent" -> R.drawable.baseline_home_24
            "Electricity" -> R.drawable.electricity
            "Water" -> R.drawable.water
            "Gas" -> R.drawable.gas
            "Garbage" -> R.drawable.garbage
            "Credit card" -> R.drawable.credit_card
            "Travel" -> R.drawable.travel
            "Insurance" -> R.drawable.handshake
            "Medicine" -> R.drawable.medical
            "Mobile" -> R.drawable.phone
            "Internet" -> R.drawable.internet
            "Television" -> R.drawable.tv
            "Create" -> R.drawable.create
            else -> R.drawable.default_icon
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(bill: Bill, fromPaid: Boolean = false) =
            BillDetailsDialog().apply {
                arguments = Bundle().apply {
                    putParcelable("bill", bill)
                    putBoolean("fromPaid", fromPaid)
                }
            }
    }
}
