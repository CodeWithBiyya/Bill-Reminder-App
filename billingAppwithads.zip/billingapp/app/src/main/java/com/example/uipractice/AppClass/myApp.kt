package com.example.uipractice.AppClass

import android.app.Application
import com.example.uipractice.database.FirestoreDatabase
import com.google.firebase.FirebaseApp
import com.jakewharton.threetenabp.AndroidThreeTen

class MyApp : Application() {
    companion object {
        lateinit var database: FirestoreDatabase
            private set
    }

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        database = FirestoreDatabase.getDatabase()
        AndroidThreeTen.init(this)
    }
}
