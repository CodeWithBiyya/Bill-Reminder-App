package com.example.uipractice.fragments

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.uipractice.R
import com.example.uipractice.adapters.BillAdapter
import com.example.uipractice.adapters.OnBillClickListener
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.databinding.FragmentAllfilesBinding
import com.example.uipractice.viewmodel.BillViewModel
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.material.tabs.TabLayoutMediator

class AllFilesFragment : Fragment(), OnBillClickListener, BillDetailsDialog.BillDetailsDialogListener {

    private var _binding: FragmentAllfilesBinding? = null
    private val binding get() = _binding!!
    private lateinit var billViewModel: BillViewModel
    private lateinit var billAdapter: BillAdapter
    private val adItems = mutableListOf<Any>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAllfilesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set up back button
        binding.imageView.setOnClickListener {
            requireActivity().onBackPressed()
        }

        // Initialize the ViewModel
        billViewModel = ViewModelProvider(this)[BillViewModel::class.java]

        val currencySymbol = getSelectedCurrencySymbol(requireContext())

        // Set up RecyclerView with BillAdapter
        billAdapter = BillAdapter(this, currencySymbol)
        binding.recyclerViewBills.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = billAdapter
        }

        // Set up ViewPager and TabLayout
        val viewPagerAdapter = ViewPagerAdapter(this)
        binding.viewPager.adapter = viewPagerAdapter
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "Upcoming"
                1 -> "Paid"
                2 -> "Overdue"
                3 -> "Recurring"
                else -> "Unknown"
            }
        }.attach()

        // Observe bill lists based on status
        billViewModel.upcomingBills.observe(viewLifecycleOwner, Observer { bills ->
            if (binding.viewPager.currentItem == 0) {
                adItems.clear()
                adItems.addAll(bills)
                loadNativeAds() // Insert ads after bills are loaded
                Log.d("AllFiles", "Upcoming bills: ${bills.size}")
            }
        })

        billViewModel.paidBills.observe(viewLifecycleOwner, Observer { bills ->
            if (binding.viewPager.currentItem == 1) {
                billAdapter.submitList(bills)
            }
        })

        billViewModel.overdueBills.observe(viewLifecycleOwner, Observer { bills ->
            if (binding.viewPager.currentItem == 2) {
                billAdapter.submitList(bills)
                Log.d("AllFiles", "Overdue bills: ${bills.size}")
            }
        })

        billViewModel.recurringBills.observe(viewLifecycleOwner, Observer { bills ->
            if (binding.viewPager.currentItem == 3) {
                billAdapter.submitList(bills)
            }
        })

        // Ensure bills are loaded
        billViewModel.loadBills()
    }

    // Load native ads and insert them into the list
    private fun loadNativeAds() {
        val adLoader = AdLoader.Builder(requireContext(), "ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX")
            .forNativeAd { nativeAd ->
                // Insert the ad every 4th item in the list
                for (i in adItems.indices step 4) {
                    if (i < adItems.size) {
                        adItems.add(i, nativeAd)
                    }
                }
                billAdapter.submitList(adItems)
            }
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    private fun getSelectedCurrencySymbol(context: Context): String {
        val sharedPreferences = context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("selected_currency_symbol", "$") ?: "$"
    }

    override fun onBillClicked(bill: Bill) {
        Toast.makeText(requireContext(), "Clicked on: ${bill.description}", Toast.LENGTH_SHORT).show()
        val dialog = BillDetailsDialog.newInstance(bill)
        val bundle = Bundle().apply {
            putParcelable("bill", bill) // Ensure Bill is Parcelable
        }
        dialog.arguments = bundle
        dialog.show(parentFragmentManager, "BillDetailsDialog")
    }

    // Navigate to ScanFragment
    override fun onNavigateToScanFragment() {
        try {
            findNavController().navigate(R.id.action_allFilesFragment_to_scanFragment)
        } catch (e: IllegalArgumentException) {
            Log.e("NavigationError", "Navigation action not found: ${e.message}")
        }
    }

    private inner class ViewPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {
        override fun getItemCount(): Int = 4
        override fun createFragment(position: Int): Fragment {
            return when (position) {
                0 -> BillListFragment.newInstance(Bill.BillStatus.UPCOMING)
                1 -> BillListFragment.newInstance(Bill.BillStatus.PAID)
                2 -> BillListFragment.newInstance(Bill.BillStatus.OVERDUE)
                3 -> BillListFragment.newInstance(Bill.BillStatus.RECURRING)
                else -> throw IllegalStateException("Unknown tab position: $position")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
