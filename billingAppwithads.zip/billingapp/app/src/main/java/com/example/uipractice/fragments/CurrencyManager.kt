package com.example.uipractice.fragments

import android.content.Context

class CurrencyManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("currency_prefs", Context.MODE_PRIVATE)

    fun saveSelectedCurrency(currency: String) {
        prefs.edit().putString("selected_currency", currency).apply()
    }

    fun getSelectedCurrency(): String {
        return prefs.getString("selected_currency", "Dollar ($)") ?: "Dollar ($)"
    }
}

