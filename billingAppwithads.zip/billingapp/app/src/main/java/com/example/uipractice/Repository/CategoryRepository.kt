package com.example.uipractice.Repository

import com.example.uipractice.dataClasses.Category
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.tasks.await

class CategoryRepository {

    private val db = FirebaseFirestore.getInstance()
    private val categoriesCollection = db.collection("categories")

    // Fetch all categories
    suspend fun getAllCategories(): List<Category> {
        return try {
            val snapshot = categoriesCollection.get().await()
            snapshot.toObjects(Category::class.java)
        } catch (e: Exception) {
            // Handle exception
            emptyList()
        }
    }

    // Insert a new category
    suspend fun insert(category: Category): Boolean {
        return try {
            val documentRef = categoriesCollection.add(category).await()
            documentRef.id.isNotEmpty()
        } catch (e: Exception) {
            // Handle exception
            false
        }
    }

    // Optional: To observe changes in real-time
    fun observeCategories(callback: (List<Category>) -> Unit): ListenerRegistration {
        return categoriesCollection.addSnapshotListener { snapshot, exception ->
            if (exception != null) {
                // Handle the error
                return@addSnapshotListener
            }
            val categories = snapshot?.toObjects(Category::class.java) ?: emptyList()
            callback(categories)
        }
    }
}
