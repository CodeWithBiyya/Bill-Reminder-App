package com.example.uipractice.adapters

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.uipractice.R
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.databinding.ItemBillBinding
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

class BillAdapter(
    private val onBillClickListener: OnBillClickListener,
    private val currencySymbol: String
) : ListAdapter<Any, RecyclerView.ViewHolder>(BillDiffCallback()) {

    companion object {
        private const val VIEW_TYPE_BILL = 0
        private const val VIEW_TYPE_AD = 1
    }

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is Bill -> VIEW_TYPE_BILL
            is NativeAd -> VIEW_TYPE_AD
            else -> throw IllegalArgumentException("Unsupported item type at position $position")
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_BILL -> {
                val binding = ItemBillBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                BillViewHolder(binding)
            }
            VIEW_TYPE_AD -> {
                val view = LayoutInflater.from(parent.context)
                    .inflate(R.layout.layout_native_ad, parent, false)
                AdViewHolder(view)
            }
            else -> throw IllegalArgumentException("Unsupported view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is Bill -> (holder as BillViewHolder).bind(item)
            is NativeAd -> (holder as AdViewHolder).bind(item)
        }
    }

    inner class BillViewHolder(private val binding: ItemBillBinding) : RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("SetTextI18n")
        fun bind(bill: Bill) {
            binding.apply {
                ivIcon.setImageResource(getIconResource(bill.category))
                tvName.text = bill.description
                tvDueDate.text = "Due date: ${bill.dueDate}"
                tvAmount.text = "$currencySymbol${bill.amount}" // Use the currency symbol
                root.setOnClickListener { onBillClickListener.onBillClicked(bill) }
            }
        }

        private fun getIconResource(category: String): Int {
            return when (category) {
                "House Rent" -> R.drawable.baseline_home_24
                "Electricity" -> R.drawable.electric_shock
                "Water" -> R.drawable.water
                "Gas" -> R.drawable.gas
                "Garbage" -> R.drawable.garbage
                "Credit card" -> R.drawable.credit_card
                "Travel" -> R.drawable.travel
                "Insurance" -> R.drawable.handshake
                "Medicine" -> R.drawable.medical
                "Mobile" -> R.drawable.phone
                "Internet" -> R.drawable.internet
                "Television" -> R.drawable.tv
                "Create" -> R.drawable.create
                else -> R.drawable.default_icon
            }
        }
    }

    inner class AdViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nativeAdView: NativeAdView = itemView.findViewById(R.id.native_ad_view)

        fun bind(nativeAd: NativeAd) {
            nativeAdView.headlineView = nativeAdView.findViewById(R.id.ad_headline)
            nativeAdView.bodyView = nativeAdView.findViewById(R.id.ad_body)
            nativeAdView.iconView = nativeAdView.findViewById(R.id.ad_icon)
            nativeAdView.callToActionView = nativeAdView.findViewById(R.id.ad_call_to_action)

            // Populate NativeAdView with ad content
            (nativeAdView.headlineView as TextView).text = nativeAd.headline
            (nativeAdView.bodyView as TextView).text = nativeAd.body
            nativeAd.icon?.let { (nativeAdView.iconView as ImageView).setImageDrawable(it.drawable) }
            (nativeAdView.callToActionView as Button).text = nativeAd.callToAction

            nativeAdView.setNativeAd(nativeAd)
        }
    }

    private class BillDiffCallback : DiffUtil.ItemCallback<Any>() {
        override fun areItemsTheSame(oldItem: Any, newItem: Any): Boolean {
            return if (oldItem is Bill && newItem is Bill) {
                oldItem.id == newItem.id
            } else oldItem === newItem
        }

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: Any, newItem: Any): Boolean {
            return oldItem == newItem
        }
    }
}
