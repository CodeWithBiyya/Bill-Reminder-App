package com.example.uipractice.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import com.example.uipractice.dataClasses.Bill
import com.example.uipractice.repository.BillRepository
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.ParseException
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.*

class BillViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BillRepository()
    private val db = FirebaseFirestore.getInstance()  // Firestore instance


    // LiveData to observe all bills
    private val _allBills = MutableLiveData<List<Bill>>()
    val allBills: LiveData<List<Bill>> get() = _allBills

    private val _paidBills = MutableLiveData<List<Bill>>()
    val paidBills: LiveData<List<Bill>> get() = _paidBills

    private val _upcomingBills = MutableLiveData<List<Bill>>()
    val upcomingBills: LiveData<List<Bill>> get() = _upcomingBills

    private val _recurringBills = MutableLiveData<List<Bill>>()
    val recurringBills: LiveData<List<Bill>> get() = _recurringBills

    private val _overdueBills = MutableLiveData<List<Bill>>()
    val overdueBills: LiveData<List<Bill>> get() = _overdueBills

    init {
        loadBills()
    }

    // Load all bills and update LiveData
    fun loadBills() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                checkAndUpdateBillStatuses()

                val paidBills = repository.getBillsByStatus(Bill.BillStatus.PAID)
                val upcomingBills = repository.getBillsByStatus(Bill.BillStatus.UPCOMING)
                val recurringBills = repository.getRecurringBills()
                val overdueBills = repository.getOverdueBills(System.currentTimeMillis())

                withContext(Dispatchers.Main) {
                    _paidBills.value = paidBills
                    _upcomingBills.value = upcomingBills
                    _recurringBills.value = recurringBills
                    _overdueBills.value = overdueBills
                }

                Log.d("BillViewModel", "Bills loaded successfully")
            } catch (e: Exception) {
                Log.e("BillViewModel", "Error loading bills", e)
            }
        }
    }
////
//    fun getAllBills(): LiveData<List<Bill>> {
//        return allBills
//    }

    // Insert a new bill
    fun insertBill(bill: Bill) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = repository.insertBill(bill)
            if (success) {
                loadBills()
            }
        }
    }

    // Delete a bill
    fun deleteBill(billId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = repository.deleteBill(billId)
            if (success) {
                loadBills()
            }
        }
    }

    fun getBillsByCategory(category: String): LiveData<List<Bill>> {
        val billsLiveData = MutableLiveData<List<Bill>>()

        // Fetch bills from Firestore
        db.collection("bills")
            .whereEqualTo("category", category)
            .get()
            .addOnSuccessListener { querySnapshot ->
                val bills = querySnapshot.toObjects(Bill::class.java)
                billsLiveData.value = bills
            }
            .addOnFailureListener {
                billsLiveData.value = emptyList()  // In case of error, return an empty list
            }

        return billsLiveData
    }



    // Mark bill as paid
    fun markAsPaid(bill: Bill) {
        viewModelScope.launch(Dispatchers.IO) {
            val updates = mapOf(
                "isPaid" to true,
                "status" to Bill.BillStatus.PAID.name
            )
            val success = repository.updateBill(bill.id.toString(), updates)
            if (success) {
                generateNextRecurringBill(bill)
                loadBills()
            }
        }
    }

    // Check and update bill statuses
    private fun checkAndUpdateBillStatuses() {
        viewModelScope.launch(Dispatchers.IO) {
            val allBills = repository.getAllBills()
            val currentDate = System.currentTimeMillis()

            allBills.forEach { bill ->
                val dueDate = parseDateStringToMillis(bill.dueDate)

                if (dueDate != null) {
                    val updates = mutableMapOf<String, Any>()
                    if (dueDate < currentDate && bill.status != Bill.BillStatus.PAID) {
                        updates["status"] = Bill.BillStatus.OVERDUE.name
                    } else if (dueDate >= currentDate && bill.status != Bill.BillStatus.PAID) {
                        updates["status"] = Bill.BillStatus.UPCOMING.name
                    }

                    if (updates.isNotEmpty()) {
                        repository.updateBill(bill.id.toString(), updates)
                    }
                } else {
                    Log.e("BillViewModel", "Failed to parse due date for bill: ${bill.description}")
                }
            }
        }
    }

    // Helper function to parse date string to milliseconds (Long)
    private fun parseDateStringToMillis(dateString: String?): Long? {
        return try {
            val formatter = DateTimeFormatter.ofPattern("HH:mm dd/MM/yyyy")
            val localDateTime = LocalDateTime.parse(dateString, formatter)
            localDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        } catch (e: Exception) {
            Log.e("BillViewModel", "Error parsing date: $dateString", e)
            null
        }
    }

    // Generate the next recurring bill
    private fun generateNextRecurringBill(bill: Bill?) {
        if (bill == null) return

        val calendar = Calendar.getInstance()
        val parsedDate = parseDate(bill.dueDate)
        if (parsedDate == null) return

        calendar.time = parsedDate

        when (bill.frequency) {
            Bill.Frequency.ONCE -> return
            Bill.Frequency.DAILY -> calendar.add(Calendar.DAY_OF_YEAR, 1)
            Bill.Frequency.WEEKLY -> calendar.add(Calendar.WEEK_OF_YEAR, 1)
            Bill.Frequency.MONTHLY -> calendar.add(Calendar.MONTH, 1)
            Bill.Frequency.YEARLY -> calendar.add(Calendar.YEAR, 1)
        }

        val newDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)
        val newBill = bill.copy(
            id = UUID.randomUUID().toString(),
            dueDate = newDueDate,
            isPaid = false,
            status = Bill.BillStatus.UPCOMING
        )

        insertBill(newBill)
    }

    private fun parseDate(dateString: String?): Date? {
        return try {
            SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(dateString)
        } catch (e: ParseException) {
            Log.e("BillViewModel", "Error parsing date", e)
            null
        }
    }
}
