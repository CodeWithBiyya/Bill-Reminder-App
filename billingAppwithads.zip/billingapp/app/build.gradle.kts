plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
    id("org.jetbrains.kotlin.kapt")
    id("org.jetbrains.kotlin.plugin.parcelize")
    id ("com.google.gms.google-services")

}

android {
    compileSdk = 34

    defaultConfig {
        applicationId = "com.billremider.budgetplanner.free"
        minSdk = 28
        targetSdk = 34
        versionCode = 4
        versionName = "1.4"
        namespace = "com.example.uipractice"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }


    buildFeatures {
        dataBinding = true
        viewBinding = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }
}


dependencies {
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.recyclerview.v121)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.material.v140)
    implementation(libs.androidx.core.ktx.v1131)
    implementation(libs.androidx.navigation.fragment.ktx)
    implementation(libs.androidx.navigation.ui.ktx.v253)
   // implementation(libs.appcompat)
    implementation(libs.androidx.fragment.ktx)
    implementation(libs.androidx.room.ktx)
    implementation(libs.androidx.viewpager2)
    implementation(libs.androidx.ui.desktop)
    implementation(libs.firebase.firestore.ktx)

    //noinspection KaptUsageInsteadOfKsp
    kapt(libs.androidx.room.compiler)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit.v121)
    androidTestImplementation(libs.androidx.espresso.core.v361)
    implementation(libs.ssp.android)
    implementation(libs.sdp.android)
    implementation(libs.androidx.lifecycle.extensions)
    implementation (libs.androidx.lifecycle.viewmodel.ktx)
    implementation (libs.androidx.lifecycle.livedata.ktx)
    implementation (libs.material.calendarview)
    implementation (libs.mpandroidchart)

    implementation (libs.threetenabp)

    // CameraX
    implementation (libs.androidx.camera.core)
    implementation (libs.androidx.camera.camera2)
    implementation (libs.androidx.camera.lifecycle)
    implementation (libs.androidx.camera.view)

    implementation (libs.guava)

    // ML Kit Barcode Scanning

    implementation (libs.glide)
    annotationProcessor (libs.compiler)

    implementation (libs.picasso)

    // firebase
    platform(libs.firebase.bom)
    implementation (libs.firebase.firestore)

    implementation (libs.firebase.storage)
    implementation (libs.firebase.analytics) // Optional, for Firebase Analytics

    implementation (libs.firebase.firestore.ktx)

    implementation (libs.kotlinx.coroutines.core) // or the latest version
    implementation (libs.kotlinx.coroutines.android) // or the latest version

    implementation(libs.play.services.ads)

}
